﻿namespace MyBagelShopAssignment
{
    partial class SummaryMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SummaryMainForm));
            this.SummaryForm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TotalBagelSoldLabel = new System.Windows.Forms.Label();
            this.TotalBagelSoldLabel1 = new System.Windows.Forms.Label();
            this.AvgTransactiosnLabel = new System.Windows.Forms.Label();
            this.TotalTnxlabel = new System.Windows.Forms.Label();
            this.TotalSaleValueLabel = new System.Windows.Forms.Label();
            this.TotalTnxlabel1 = new System.Windows.Forms.Label();
            this.TotalSaleValueLabel1 = new System.Windows.Forms.Label();
            this.AvgTransactiosnLabel1 = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SummaryForm
            // 
            this.SummaryForm.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.SummaryForm.Name = "SummaryForm";
            this.SummaryForm.Size = new System.Drawing.Size(61, 4);
            // 
            // TotalBagelSoldLabel
            // 
            this.TotalBagelSoldLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalBagelSoldLabel.Location = new System.Drawing.Point(12, 131);
            this.TotalBagelSoldLabel.Name = "TotalBagelSoldLabel";
            this.TotalBagelSoldLabel.Size = new System.Drawing.Size(183, 33);
            this.TotalBagelSoldLabel.TabIndex = 1;
            this.TotalBagelSoldLabel.Text = "Total Bagle\'s Sold";
            // 
            // TotalBagelSoldLabel1
            // 
            this.TotalBagelSoldLabel1.BackColor = System.Drawing.SystemColors.Menu;
            this.TotalBagelSoldLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalBagelSoldLabel1.Location = new System.Drawing.Point(230, 131);
            this.TotalBagelSoldLabel1.Name = "TotalBagelSoldLabel1";
            this.TotalBagelSoldLabel1.Size = new System.Drawing.Size(110, 33);
            this.TotalBagelSoldLabel1.TabIndex = 2;
            // 
            // AvgTransactiosnLabel
            // 
            this.AvgTransactiosnLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AvgTransactiosnLabel.Location = new System.Drawing.Point(12, 287);
            this.AvgTransactiosnLabel.Name = "AvgTransactiosnLabel";
            this.AvgTransactiosnLabel.Size = new System.Drawing.Size(183, 33);
            this.AvgTransactiosnLabel.TabIndex = 3;
            this.AvgTransactiosnLabel.Text = "Avg Transaction";
            // 
            // TotalTnxlabel
            // 
            this.TotalTnxlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalTnxlabel.Location = new System.Drawing.Point(12, 233);
            this.TotalTnxlabel.Name = "TotalTnxlabel";
            this.TotalTnxlabel.Size = new System.Drawing.Size(193, 33);
            this.TotalTnxlabel.TabIndex = 4;
            this.TotalTnxlabel.Text = "Total Tansacations";
            // 
            // TotalSaleValueLabel
            // 
            this.TotalSaleValueLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalSaleValueLabel.Location = new System.Drawing.Point(12, 180);
            this.TotalSaleValueLabel.Name = "TotalSaleValueLabel";
            this.TotalSaleValueLabel.Size = new System.Drawing.Size(183, 33);
            this.TotalSaleValueLabel.TabIndex = 5;
            this.TotalSaleValueLabel.Text = "Total Sale Value";
            // 
            // TotalTnxlabel1
            // 
            this.TotalTnxlabel1.BackColor = System.Drawing.SystemColors.Menu;
            this.TotalTnxlabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalTnxlabel1.Location = new System.Drawing.Point(230, 233);
            this.TotalTnxlabel1.Name = "TotalTnxlabel1";
            this.TotalTnxlabel1.Size = new System.Drawing.Size(110, 33);
            this.TotalTnxlabel1.TabIndex = 6;
            // 
            // TotalSaleValueLabel1
            // 
            this.TotalSaleValueLabel1.BackColor = System.Drawing.SystemColors.Menu;
            this.TotalSaleValueLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalSaleValueLabel1.Location = new System.Drawing.Point(230, 180);
            this.TotalSaleValueLabel1.Name = "TotalSaleValueLabel1";
            this.TotalSaleValueLabel1.Size = new System.Drawing.Size(110, 33);
            this.TotalSaleValueLabel1.TabIndex = 7;
            // 
            // AvgTransactiosnLabel1
            // 
            this.AvgTransactiosnLabel1.BackColor = System.Drawing.SystemColors.Menu;
            this.AvgTransactiosnLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AvgTransactiosnLabel1.Location = new System.Drawing.Point(230, 287);
            this.AvgTransactiosnLabel1.Name = "AvgTransactiosnLabel1";
            this.AvgTransactiosnLabel1.Size = new System.Drawing.Size(110, 33);
            this.AvgTransactiosnLabel1.TabIndex = 8;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(147, 337);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(94, 29);
            this.ExitButton.TabIndex = 9;
            this.ExitButton.Text = "E&xit";
            this.toolTip1.SetToolTip(this.ExitButton, "Pree to Exit");
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MyBagelShopAssignment.Properties.Resources.MyBagelShopMedium;
            this.pictureBox1.Location = new System.Drawing.Point(70, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(244, 105);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // SummaryMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(420, 378);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.AvgTransactiosnLabel1);
            this.Controls.Add(this.TotalSaleValueLabel1);
            this.Controls.Add(this.TotalTnxlabel1);
            this.Controls.Add(this.TotalSaleValueLabel);
            this.Controls.Add(this.TotalTnxlabel);
            this.Controls.Add(this.AvgTransactiosnLabel);
            this.Controls.Add(this.TotalBagelSoldLabel1);
            this.Controls.Add(this.TotalBagelSoldLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SummaryMainForm";
            this.Text = "Summary";
            this.Load += new System.EventHandler(this.SummaryMainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ContextMenuStrip SummaryForm;
        private Label TotalBagelSoldLabel;
        private Label TotalBagelSoldLabel1;
        private Label AvgTransactiosnLabel;
        private Label TotalTnxlabel;
        private Label TotalSaleValueLabel;
        private Label TotalTnxlabel1;
        private Label TotalSaleValueLabel1;
        private Label AvgTransactiosnLabel1;
        private Button ExitButton;
        private PictureBox pictureBox1;
        private ToolTip toolTip1;
    }
}