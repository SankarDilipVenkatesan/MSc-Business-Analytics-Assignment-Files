﻿namespace MyBagelShopAssignment
{
    partial class MBSIMainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MBSIMainForm));
            this.BagelTypeListBox = new System.Windows.Forms.ListBox();
            this.BagelSizeListBox = new System.Windows.Forms.ListBox();
            this.MBSIPictureBox = new System.Windows.Forms.PictureBox();
            this.BagelSizeLabel = new System.Windows.Forms.Label();
            this.BagelTypeLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TrxnLabel = new System.Windows.Forms.Label();
            this.AddToCartButton = new System.Windows.Forms.Button();
            this.UpDownOperator = new System.Windows.Forms.NumericUpDown();
            this.QuantityLabel1 = new System.Windows.Forms.Label();
            this.PriceLabel1 = new System.Windows.Forms.Label();
            this.PriceLabel2 = new System.Windows.Forms.Label();
            this.ClearButton = new System.Windows.Forms.Button();
            this.CartPriceLabel = new System.Windows.Forms.Label();
            this.CartPanel = new System.Windows.Forms.Panel();
            this.CartPanelLabel = new System.Windows.Forms.Label();
            this.CartBagelLabel = new System.Windows.Forms.Label();
            this.CartBagelSize = new System.Windows.Forms.Label();
            this.CartQuantityLabel = new System.Windows.Forms.Label();
            this.BagelShowCartView = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.TotalPriceLabel1 = new System.Windows.Forms.Label();
            this.TotalPriceLabel2 = new System.Windows.Forms.Label();
            this.DecisionPanel = new System.Windows.Forms.Panel();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SalesReportButton = new System.Windows.Forms.Button();
            this.StockReportButton = new System.Windows.Forms.Button();
            this.SummaryButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.MBSIPictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpDownOperator)).BeginInit();
            this.CartPanel.SuspendLayout();
            this.DecisionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BagelTypeListBox
            // 
            this.BagelTypeListBox.FormattingEnabled = true;
            this.BagelTypeListBox.ItemHeight = 20;
            this.BagelTypeListBox.Location = new System.Drawing.Point(21, 76);
            this.BagelTypeListBox.Name = "BagelTypeListBox";
            this.BagelTypeListBox.Size = new System.Drawing.Size(171, 284);
            this.BagelTypeListBox.TabIndex = 0;
            this.BagelTypeListBox.SelectedIndexChanged += new System.EventHandler(this.BagelTypeListBox_SelectedIndexChanged);
            // 
            // BagelSizeListBox
            // 
            this.BagelSizeListBox.FormattingEnabled = true;
            this.BagelSizeListBox.ItemHeight = 20;
            this.BagelSizeListBox.Location = new System.Drawing.Point(216, 76);
            this.BagelSizeListBox.Name = "BagelSizeListBox";
            this.BagelSizeListBox.Size = new System.Drawing.Size(150, 124);
            this.BagelSizeListBox.TabIndex = 1;
            this.BagelSizeListBox.SelectedIndexChanged += new System.EventHandler(this.BagelSizeListBox_SelectedIndexChanged);
            // 
            // MBSIPictureBox
            // 
            this.MBSIPictureBox.Image = global::MyBagelShopAssignment.Properties.Resources.MyBagelShopMedium;
            this.MBSIPictureBox.Location = new System.Drawing.Point(78, 12);
            this.MBSIPictureBox.Name = "MBSIPictureBox";
            this.MBSIPictureBox.Size = new System.Drawing.Size(319, 131);
            this.MBSIPictureBox.TabIndex = 2;
            this.MBSIPictureBox.TabStop = false;
            // 
            // BagelSizeLabel
            // 
            this.BagelSizeLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BagelSizeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BagelSizeLabel.Location = new System.Drawing.Point(216, 36);
            this.BagelSizeLabel.Name = "BagelSizeLabel";
            this.BagelSizeLabel.Size = new System.Drawing.Size(151, 25);
            this.BagelSizeLabel.TabIndex = 3;
            this.BagelSizeLabel.Text = "Bagel Size Available";
            // 
            // BagelTypeLabel
            // 
            this.BagelTypeLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BagelTypeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BagelTypeLabel.Location = new System.Drawing.Point(21, 36);
            this.BagelTypeLabel.Name = "BagelTypeLabel";
            this.BagelTypeLabel.Size = new System.Drawing.Size(172, 25);
            this.BagelTypeLabel.TabIndex = 4;
            this.BagelTypeLabel.Text = "Bagel Options Available";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.TrxnLabel);
            this.panel1.Controls.Add(this.AddToCartButton);
            this.panel1.Controls.Add(this.UpDownOperator);
            this.panel1.Controls.Add(this.QuantityLabel1);
            this.panel1.Controls.Add(this.PriceLabel1);
            this.panel1.Controls.Add(this.PriceLabel2);
            this.panel1.Controls.Add(this.BagelTypeListBox);
            this.panel1.Controls.Add(this.BagelTypeLabel);
            this.panel1.Controls.Add(this.BagelSizeListBox);
            this.panel1.Controls.Add(this.BagelSizeLabel);
            this.panel1.Location = new System.Drawing.Point(12, 149);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(402, 462);
            this.panel1.TabIndex = 5;
            // 
            // TrxnLabel
            // 
            this.TrxnLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.TrxnLabel.Location = new System.Drawing.Point(215, 218);
            this.TrxnLabel.Name = "TrxnLabel";
            this.TrxnLabel.Size = new System.Drawing.Size(151, 44);
            this.TrxnLabel.TabIndex = 25;
            this.TrxnLabel.Text = "Trxn already exists!\r\nHence Creating New.";
            // 
            // AddToCartButton
            // 
            this.AddToCartButton.BackColor = System.Drawing.SystemColors.Menu;
            this.AddToCartButton.Location = new System.Drawing.Point(127, 415);
            this.AddToCartButton.Name = "AddToCartButton";
            this.AddToCartButton.Size = new System.Drawing.Size(110, 29);
            this.AddToCartButton.TabIndex = 10;
            this.AddToCartButton.Text = "A&dd To Cart";
            this.toolTip1.SetToolTip(this.AddToCartButton, "Click To \r\nAdd Item to Cart");
            this.AddToCartButton.UseVisualStyleBackColor = false;
            this.AddToCartButton.Click += new System.EventHandler(this.AddToCartButton_Click);
            // 
            // UpDownOperator
            // 
            this.UpDownOperator.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UpDownOperator.Location = new System.Drawing.Point(333, 377);
            this.UpDownOperator.Name = "UpDownOperator";
            this.UpDownOperator.Size = new System.Drawing.Size(61, 27);
            this.UpDownOperator.TabIndex = 9;
            this.UpDownOperator.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // QuantityLabel1
            // 
            this.QuantityLabel1.Location = new System.Drawing.Point(202, 377);
            this.QuantityLabel1.Name = "QuantityLabel1";
            this.QuantityLabel1.Size = new System.Drawing.Size(125, 25);
            this.QuantityLabel1.TabIndex = 8;
            this.QuantityLabel1.Text = "Number of Items";
            this.QuantityLabel1.Click += new System.EventHandler(this.QuantityLabel1_Click);
            // 
            // PriceLabel1
            // 
            this.PriceLabel1.Location = new System.Drawing.Point(21, 378);
            this.PriceLabel1.Name = "PriceLabel1";
            this.PriceLabel1.Size = new System.Drawing.Size(46, 25);
            this.PriceLabel1.TabIndex = 6;
            this.PriceLabel1.Text = "Price:";
            // 
            // PriceLabel2
            // 
            this.PriceLabel2.BackColor = System.Drawing.SystemColors.MenuBar;
            this.PriceLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PriceLabel2.Location = new System.Drawing.Point(87, 377);
            this.PriceLabel2.Name = "PriceLabel2";
            this.PriceLabel2.Size = new System.Drawing.Size(105, 25);
            this.PriceLabel2.TabIndex = 5;
            // 
            // ClearButton
            // 
            this.ClearButton.BackColor = System.Drawing.SystemColors.Menu;
            this.ClearButton.Location = new System.Drawing.Point(62, 80);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(115, 29);
            this.ClearButton.TabIndex = 12;
            this.ClearButton.Text = "C&lear";
            this.toolTip1.SetToolTip(this.ClearButton, "Click to\r\nClear Cart");
            this.ClearButton.UseVisualStyleBackColor = false;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // CartPriceLabel
            // 
            this.CartPriceLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CartPriceLabel.Location = new System.Drawing.Point(736, 225);
            this.CartPriceLabel.Name = "CartPriceLabel";
            this.CartPriceLabel.Size = new System.Drawing.Size(90, 27);
            this.CartPriceLabel.TabIndex = 17;
            this.CartPriceLabel.Text = "Price";
            this.CartPriceLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CartPanel
            // 
            this.CartPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CartPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CartPanel.Controls.Add(this.CartPanelLabel);
            this.CartPanel.Location = new System.Drawing.Point(434, 149);
            this.CartPanel.Name = "CartPanel";
            this.CartPanel.Size = new System.Drawing.Size(408, 70);
            this.CartPanel.TabIndex = 18;
            // 
            // CartPanelLabel
            // 
            this.CartPanelLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.CartPanelLabel.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CartPanelLabel.Location = new System.Drawing.Point(95, 23);
            this.CartPanelLabel.Name = "CartPanelLabel";
            this.CartPanelLabel.Size = new System.Drawing.Size(201, 38);
            this.CartPanelLabel.TabIndex = 0;
            this.CartPanelLabel.Text = "Items in Cart";
            this.CartPanelLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CartBagelLabel
            // 
            this.CartBagelLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CartBagelLabel.Location = new System.Drawing.Point(445, 225);
            this.CartBagelLabel.Name = "CartBagelLabel";
            this.CartBagelLabel.Size = new System.Drawing.Size(96, 27);
            this.CartBagelLabel.TabIndex = 20;
            this.CartBagelLabel.Text = "Bagel Type";
            this.CartBagelLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CartBagelSize
            // 
            this.CartBagelSize.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CartBagelSize.Location = new System.Drawing.Point(547, 225);
            this.CartBagelSize.Name = "CartBagelSize";
            this.CartBagelSize.Size = new System.Drawing.Size(87, 27);
            this.CartBagelSize.TabIndex = 19;
            this.CartBagelSize.Text = "Bagel Size";
            this.CartBagelSize.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CartQuantityLabel
            // 
            this.CartQuantityLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CartQuantityLabel.Location = new System.Drawing.Point(640, 225);
            this.CartQuantityLabel.Name = "CartQuantityLabel";
            this.CartQuantityLabel.Size = new System.Drawing.Size(90, 27);
            this.CartQuantityLabel.TabIndex = 18;
            this.CartQuantityLabel.Text = "Quantity";
            this.CartQuantityLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BagelShowCartView
            // 
            this.BagelShowCartView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.BagelShowCartView.Location = new System.Drawing.Point(434, 225);
            this.BagelShowCartView.Name = "BagelShowCartView";
            this.BagelShowCartView.Size = new System.Drawing.Size(408, 228);
            this.BagelShowCartView.TabIndex = 19;
            this.BagelShowCartView.UseCompatibleStateImageBehavior = false;
            this.BagelShowCartView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 100;
            // 
            // TotalPriceLabel1
            // 
            this.TotalPriceLabel1.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalPriceLabel1.Location = new System.Drawing.Point(62, 13);
            this.TotalPriceLabel1.Name = "TotalPriceLabel1";
            this.TotalPriceLabel1.Size = new System.Drawing.Size(115, 31);
            this.TotalPriceLabel1.TabIndex = 21;
            this.TotalPriceLabel1.Text = "Total Price:";
            // 
            // TotalPriceLabel2
            // 
            this.TotalPriceLabel2.BackColor = System.Drawing.SystemColors.Window;
            this.TotalPriceLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalPriceLabel2.Location = new System.Drawing.Point(183, 13);
            this.TotalPriceLabel2.Name = "TotalPriceLabel2";
            this.TotalPriceLabel2.Size = new System.Drawing.Size(116, 31);
            this.TotalPriceLabel2.TabIndex = 22;
            // 
            // DecisionPanel
            // 
            this.DecisionPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.DecisionPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DecisionPanel.Controls.Add(this.ConfirmButton);
            this.DecisionPanel.Controls.Add(this.ClearButton);
            this.DecisionPanel.Controls.Add(this.TotalPriceLabel2);
            this.DecisionPanel.Controls.Add(this.TotalPriceLabel1);
            this.DecisionPanel.Location = new System.Drawing.Point(434, 474);
            this.DecisionPanel.Name = "DecisionPanel";
            this.DecisionPanel.Size = new System.Drawing.Size(408, 137);
            this.DecisionPanel.TabIndex = 13;
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.BackColor = System.Drawing.SystemColors.MenuBar;
            this.ConfirmButton.Location = new System.Drawing.Point(205, 80);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(159, 29);
            this.ConfirmButton.TabIndex = 1;
            this.ConfirmButton.Text = "C&onfirm Order";
            this.toolTip1.SetToolTip(this.ConfirmButton, "Click to\r\nConfirm Order");
            this.ConfirmButton.UseVisualStyleBackColor = false;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.OldLace;
            this.SearchButton.Location = new System.Drawing.Point(371, 633);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(118, 29);
            this.SearchButton.TabIndex = 21;
            this.SearchButton.Text = "S&earch";
            this.toolTip1.SetToolTip(this.SearchButton, "Click to\r\nSearch Transactions");
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.OldLace;
            this.ExitButton.Location = new System.Drawing.Point(640, 633);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(122, 29);
            this.ExitButton.TabIndex = 22;
            this.ExitButton.Text = "E&xit";
            this.toolTip1.SetToolTip(this.ExitButton, "Click to\r\nExit Application\r\n");
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // SalesReportButton
            // 
            this.SalesReportButton.BackColor = System.Drawing.Color.OldLace;
            this.SalesReportButton.Location = new System.Drawing.Point(215, 633);
            this.SalesReportButton.Name = "SalesReportButton";
            this.SalesReportButton.Size = new System.Drawing.Size(135, 29);
            this.SalesReportButton.TabIndex = 23;
            this.SalesReportButton.Text = "S&ales Report";
            this.toolTip1.SetToolTip(this.SalesReportButton, "Click to\r\nGenerate Sales Report\r\n");
            this.SalesReportButton.UseVisualStyleBackColor = false;
            this.SalesReportButton.Click += new System.EventHandler(this.SalesReportButton_Click);
            // 
            // StockReportButton
            // 
            this.StockReportButton.BackColor = System.Drawing.Color.OldLace;
            this.StockReportButton.Location = new System.Drawing.Point(53, 633);
            this.StockReportButton.Name = "StockReportButton";
            this.StockReportButton.Size = new System.Drawing.Size(135, 29);
            this.StockReportButton.TabIndex = 24;
            this.StockReportButton.Text = "S&tock Report";
            this.toolTip1.SetToolTip(this.StockReportButton, "Click to\r\nGenerate Stock Report");
            this.StockReportButton.UseVisualStyleBackColor = false;
            this.StockReportButton.Click += new System.EventHandler(this.StockReportButton_Click);
            // 
            // SummaryButton
            // 
            this.SummaryButton.BackColor = System.Drawing.Color.OldLace;
            this.SummaryButton.Location = new System.Drawing.Point(518, 633);
            this.SummaryButton.Name = "SummaryButton";
            this.SummaryButton.Size = new System.Drawing.Size(94, 29);
            this.SummaryButton.TabIndex = 25;
            this.SummaryButton.Text = "S&ummary";
            this.toolTip1.SetToolTip(this.SummaryButton, "Click to\r\nView Summary");
            this.SummaryButton.UseVisualStyleBackColor = false;
            this.SummaryButton.Click += new System.EventHandler(this.SummaryButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MyBagelShopAssignment.Properties.Resources.img1;
            this.pictureBox1.Location = new System.Drawing.Point(530, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(166, 122);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // MBSIMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ClientSize = new System.Drawing.Size(862, 678);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.SummaryButton);
            this.Controls.Add(this.StockReportButton);
            this.Controls.Add(this.SalesReportButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.DecisionPanel);
            this.Controls.Add(this.CartPriceLabel);
            this.Controls.Add(this.CartQuantityLabel);
            this.Controls.Add(this.CartBagelSize);
            this.Controls.Add(this.CartBagelLabel);
            this.Controls.Add(this.BagelShowCartView);
            this.Controls.Add(this.CartPanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MBSIPictureBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MBSIMainForm";
            this.Text = "MyBagelShop Inc App";
            this.Load += new System.EventHandler(this.MBSIMainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MBSIPictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.UpDownOperator)).EndInit();
            this.CartPanel.ResumeLayout(false);
            this.DecisionPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ListBox BagelTypeListBox;
        private ListBox BagelSizeListBox;
        private PictureBox MBSIPictureBox;
        private Label BagelSizeLabel;
        private Label BagelTypeLabel;
        private Panel panel1;
        private NumericUpDown UpDownOperator;
        private Label QuantityLabel1;
        private Label PriceLabel1;
        private Label PriceLabel2;
        private Button AddToCartButton;
        private Button ClearButton;
        private Label CartPriceLabel;
        private Panel CartPanel;
        private Label CartBagelLabel;
        private Label CartBagelSize;
        private Label CartQuantityLabel;
        private ListView BagelShowCartView;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private Label CartPanelLabel;
        private Label TotalPriceLabel1;
        private Label TotalPriceLabel2;
        private Panel DecisionPanel;
        private Button ConfirmButton;
        private Button SearchButton;
        private Button ExitButton;
        private Button SalesReportButton;
        private Button StockReportButton;
        private Label TrxnLabel;
        private Button SummaryButton;
        private PictureBox pictureBox1;
        private ToolTip toolTip1;
    }
}