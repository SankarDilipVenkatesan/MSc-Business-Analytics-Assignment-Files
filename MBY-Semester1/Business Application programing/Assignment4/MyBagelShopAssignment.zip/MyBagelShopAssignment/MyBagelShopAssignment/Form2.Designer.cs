﻿namespace MyBagelShopAssignment
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchForm));
            this.SearchResultsLabel = new System.Windows.Forms.Label();
            this.SearchListBox = new System.Windows.Forms.ListBox();
            this.TransactionNumberRadioButton = new System.Windows.Forms.RadioButton();
            this.TransactionDateRadioButton = new System.Windows.Forms.RadioButton();
            this.SearchTextBox = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchResultsLabel
            // 
            this.SearchResultsLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.SearchResultsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultsLabel.Location = new System.Drawing.Point(124, 38);
            this.SearchResultsLabel.Name = "SearchResultsLabel";
            this.SearchResultsLabel.Size = new System.Drawing.Size(220, 42);
            this.SearchResultsLabel.TabIndex = 0;
            this.SearchResultsLabel.Text = "Search Results";
            this.SearchResultsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SearchListBox
            // 
            this.SearchListBox.FormattingEnabled = true;
            this.SearchListBox.ItemHeight = 20;
            this.SearchListBox.Location = new System.Drawing.Point(12, 106);
            this.SearchListBox.Name = "SearchListBox";
            this.SearchListBox.Size = new System.Drawing.Size(459, 224);
            this.SearchListBox.TabIndex = 1;
            // 
            // TransactionNumberRadioButton
            // 
            this.TransactionNumberRadioButton.BackColor = System.Drawing.SystemColors.Info;
            this.TransactionNumberRadioButton.Location = new System.Drawing.Point(549, 203);
            this.TransactionNumberRadioButton.Name = "TransactionNumberRadioButton";
            this.TransactionNumberRadioButton.Size = new System.Drawing.Size(195, 30);
            this.TransactionNumberRadioButton.TabIndex = 2;
            this.TransactionNumberRadioButton.TabStop = true;
            this.TransactionNumberRadioButton.Text = "Transaction Number";
            this.TransactionNumberRadioButton.UseVisualStyleBackColor = false;
            // 
            // TransactionDateRadioButton
            // 
            this.TransactionDateRadioButton.BackColor = System.Drawing.SystemColors.Info;
            this.TransactionDateRadioButton.Location = new System.Drawing.Point(549, 239);
            this.TransactionDateRadioButton.Name = "TransactionDateRadioButton";
            this.TransactionDateRadioButton.Size = new System.Drawing.Size(195, 30);
            this.TransactionDateRadioButton.TabIndex = 3;
            this.TransactionDateRadioButton.TabStop = true;
            this.TransactionDateRadioButton.Text = "Transaction Date";
            this.TransactionDateRadioButton.UseVisualStyleBackColor = false;
            // 
            // SearchTextBox
            // 
            this.SearchTextBox.BackColor = System.Drawing.SystemColors.Menu;
            this.SearchTextBox.Location = new System.Drawing.Point(538, 275);
            this.SearchTextBox.Name = "SearchTextBox";
            this.SearchTextBox.Size = new System.Drawing.Size(230, 27);
            this.SearchTextBox.TabIndex = 4;
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(202, 368);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(94, 29);
            this.SearchButton.TabIndex = 5;
            this.SearchButton.Text = "S&earch";
            this.toolTip1.SetToolTip(this.SearchButton, "Press to\r\nSearch Transaction");
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(349, 368);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(94, 29);
            this.ClearButton.TabIndex = 6;
            this.ClearButton.Text = "C&lear";
            this.toolTip1.SetToolTip(this.ClearButton, "Press to Clear ");
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(474, 368);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(94, 29);
            this.ExitButton.TabIndex = 7;
            this.ExitButton.Text = "E&xit";
            this.toolTip1.SetToolTip(this.ExitButton, "Press to Exit");
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MyBagelShopAssignment.Properties.Resources.MyBagelShopMedium;
            this.pictureBox1.Location = new System.Drawing.Point(515, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 109);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // SearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(800, 422);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.SearchTextBox);
            this.Controls.Add(this.TransactionDateRadioButton);
            this.Controls.Add(this.TransactionNumberRadioButton);
            this.Controls.Add(this.SearchListBox);
            this.Controls.Add(this.SearchResultsLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchForm";
            this.Text = "Search Form";
            this.Load += new System.EventHandler(this.SearchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label SearchResultsLabel;
        private ListBox SearchListBox;
        private RadioButton TransactionNumberRadioButton;
        private RadioButton TransactionDateRadioButton;
        private TextBox SearchTextBox;
        private Button SearchButton;
        private Button ClearButton;
        private Button ExitButton;
        private PictureBox pictureBox1;
        private ToolTip toolTip1;
    }
}