﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//SEARCH FORM OPS
namespace MyBagelShopAssignment
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }

        bool CheckStatus; int IncrNum;
        string TransactionSummary = "Bagel_Shop_Transaction_Details.txt";

        private void SearchForm_Load(object sender, EventArgs e)
        {

        }

        //Event handler to perform search ops
        private void SearchButton_Click(object sender, EventArgs e)
        {
            if (SearchTextBox.Text == "") //Execute if condition when textbox is empty
            {
                MessageBox.Show("Please Enter Transaction date or Transaction number", "Details", MessageBoxButtons.OK,
                     MessageBoxIcon.Error);

            }
            else
            {
                try
                {
                    if ((TransactionNumberRadioButton.Checked) && !(SearchTextBox.Text.Contains("/")) && (SearchTextBox.Text.Length==5))
                    {
                        CheckStatus = true; // return true when entered and file email address matchs for search condition

                    }
                    else if ((TransactionDateRadioButton.Checked) && (SearchTextBox.Text.Contains("/")))
                    {
                        CheckStatus = true; //return true when entered and file transaction number match for search condition
                    }
                    

                    if(CheckStatus==true)
                    {
                        string[] TransactionFile = File.ReadAllLines(TransactionSummary);
                        foreach (string each in TransactionFile)
                        {
                            if (each.Contains(SearchTextBox.Text))
                            {
                                SearchListBox.Items.Add(each); //iterate and check for matching records
                                IncrNum = 1;
                            }
                            else
                            {
                                IncrNum = 0;
                            }
                        }
                        CheckStatus = false;
                    }
                    else
                    {
                        MessageBox.Show("No records found", "No records", MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                    }
                }
                catch
                {

                }
            }
        }

        ////Event handler for clear ops
        private void ClearButton_Click(object sender, EventArgs e)
        {
            SearchTextBox.Clear();
            SearchListBox.Items.Clear();
            SearchButton.Enabled = true;
            TransactionNumberRadioButton.Checked = false;
            TransactionDateRadioButton.Checked= false;
        }

        //Event handler to exit search form
        private void ExitButton_Click(object sender, EventArgs e)
        {
                this.Close();
        }
    }
}
