﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//SALES FORM OPS
namespace MyBagelShopAssignment
{
    public partial class SalesForm : Form
    {

        public SalesForm()
        {
            InitializeComponent();
        }
        //initialize sales form global variables
        const int ROWS_IN_FILE = 13, COLS_IN_FILE = 5;
        public static int[,] NewSalesArray = new int[ROWS_IN_FILE, COLS_IN_FILE];
        DateTime CurrentTime = DateTime.Now;
        string[] BagelTypes = new string[] { "Plain", "Cinnamon", "Blueberry", "Chocolate", "Onion", "Asiago", "French",
            "Egg", "Pumpernickel", "Wheat", "Garlic", "Sesame","Cheddar"};
        
        //Event handler to exit the sales form and return to MBSI form1
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //Event handler to display sales form
        private void SalesForm_Load(object sender, EventArgs e)
        {
            DateLabel.Text = CurrentTime.ToShortDateString();
            TimeLabel.Text = CurrentTime.ToShortTimeString();
            for (int j = 0; j < 13; j++) // using listview to display the stock names
            {
                ListViewItem item2 = new ListViewItem(BagelTypes[j].ToString());
                listView2.Items.Add(item2);
            }
            for (int a = 0; a < ROWS_IN_FILE; a++) //calculate remaining stock
            {
                for (int j = 0; j < COLS_IN_FILE; j++)
                {
                    NewSalesArray[a, j] = MBSIMainForm.DupicateStockInventoryArray[a, j] - MBSIMainForm.StockInventoryArray[a, j];
                    
                }
            }
            for (int i = 0; i < 13; i++) //Dispaly sales values in the list view 
            {
                ListViewItem item = new ListViewItem(NewSalesArray[i, 0].ToString());
                item.SubItems.Add(NewSalesArray[i, 1].ToString());
                item.SubItems.Add(NewSalesArray[i, 2].ToString());
                item.SubItems.Add(NewSalesArray[i, 3].ToString());
                item.SubItems.Add(NewSalesArray[i, 4].ToString());
                listView1.Items.Add(item);
            }
        }
    }
}
