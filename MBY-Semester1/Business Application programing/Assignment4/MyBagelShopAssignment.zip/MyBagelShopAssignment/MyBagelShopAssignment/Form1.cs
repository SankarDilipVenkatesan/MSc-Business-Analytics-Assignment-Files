/* Student Name: Dilip Venkatesan Sankar
 * Student ID: 22225743
 * Date: 27/11/2022
 * Assignment: 4
 * Assignment: Create an EPOS app for the MBSI staff 
 * To process customer orders and store transaction details,
 * Stock details and stock price
 */

using System;
using System.Data;

namespace MyBagelShopAssignment
{
    //Initializing global variables
    public partial class MBSIMainForm : Form
    {
        string[] BagelTypes = new string[] { "Plain", "Cinnamon", "Blueberry", "Chocolate", "Onion", "Asiago", "French",
            "Egg", "Pumpernickel", "Wheat", "Garlic", "Sesame","Cheddar"}; 
        string[] BagelSize = new string[] { "Small", "Medium", "Regular", "Large", "Extra-Large" };
        const int ROWS_IN_FILE = 13, COLS_IN_FILE = 5;
        
        const string STOCKININVENTORYFILE = "Stock_In_Inventory_Details.txt";

        public static int[,] StockInventoryArray = new int[ROWS_IN_FILE, COLS_IN_FILE]; //Load stock details to original array
        
        public static int[,] TempStockInventoryArray = new int[ROWS_IN_FILE, COLS_IN_FILE]; //Load stock details to temporary array

        public static int[,] DupicateStockInventoryArray = new int[ROWS_IN_FILE, COLS_IN_FILE]; //Make a copy of orginal array

        public static int[,] NewSalesArray = new int[ROWS_IN_FILE, COLS_IN_FILE]; //Empty array to show sale values

        const string BAGELPRICELISTFILE = "Bagel_Price_List.txt"; //Bagel price list file
        public static int[,] BagelPriceListArray = new int[ROWS_IN_FILE, COLS_IN_FILE];
        decimal BagelPrice = 0m, ItemTotal = 0m, FinalPrice = 0m;
        int QuantityStock=0, TransactionNumberOutput;
        List<string> TotalTransactionCreated = new List<string>();
        string TransactionSummary = "Bagel_Shop_Transaction_Details.txt"; //Bagel Transaction file
        DateTime Currentdate = DateTime.Now;
        string MessageDisplay; string comma = "";
        bool CheckNum;
        int SummaryTransactions, SummaryQuantity;
        decimal SummaryTotal, SummaryAvg;
        int SummaryQuantity1;

        //Ops to perform when Form loads
        public MBSIMainForm()
        {
            InitializeComponent();
            BagelTypePopulate(BagelTypes);
            BagelSizePopulate(BagelSize);
            //Loading stock values to array
            StockInventoryArray= StockInventoryArrayValues(STOCKININVENTORYFILE); 
            DupicateStockInventoryArray = StockInventoryArrayValues(STOCKININVENTORYFILE); 
            Array.Copy(StockInventoryArray, 0, TempStockInventoryArray, 0, StockInventoryArray.Length);
            BagelPriceListArray = BagelPriceListArrayValues(BAGELPRICELISTFILE);

        }

        //Event handler to populate bagel type list box
        private void BagelTypePopulate(String[] BagelTypes)
        {
            for (int BagelTypeCount = 0; BagelTypeCount < BagelTypes.Length; BagelTypeCount++)
            {
                BagelTypeListBox.Items.Add(BagelTypes[BagelTypeCount]);
            }
        }

        //Event handler to populate bagel size list box
        private void BagelSizePopulate(String[] BagelSize)
        {
            for (int BagelSizeCount = 0; BagelSizeCount < BagelSize.Length; BagelSizeCount++)
            {
                BagelSizeListBox.Items.Add(BagelSize[BagelSizeCount]);
            }
        }

        //Assigning array values from the sales inventory file
        public int[,] StockInventoryArrayValues(string StockFileName)
        {
            int[,] StockInInventoryArray = new int[ROWS_IN_FILE, COLS_IN_FILE]; //empty array
            StreamReader FileRead;
            int RowCount = 0;
            try
            {
                FileRead = File.OpenText(STOCKININVENTORYFILE); //Open Stock file to read data
                while (!FileRead.EndOfStream)
                {
                    string[] DataRead = FileRead.ReadLine().Split(','); //read line and store in array as common seperated

                    for (int ColCount = 0; ColCount < DataRead.Length; ColCount++)
                    {
                        StockInInventoryArray[RowCount, ColCount] = int.Parse(DataRead[ColCount]); //loop and read each column and store in array
                    }
                    RowCount++;
                }
                FileRead.Close();
            }
            catch (Exception Excep)
            {
                MessageBox.Show(Excep.Message);
            }
            return StockInInventoryArray;
        }

        //Assigning array values from price list file
        public int [,] BagelPriceListArrayValues(string PriceListFileName)
        {
            int[,] BagelPriceListArray = new int[ROWS_IN_FILE, COLS_IN_FILE]; //empty array
            StreamReader FileRead;
            int RowCount = 0;
            try
            {
                FileRead = File.OpenText(BAGELPRICELISTFILE); //Open Price file to read price list
                while (!FileRead.EndOfStream)
                {
                    string[] DataRead = FileRead.ReadLine().Split(','); //read line and store in array as common seperated

                    for (int ColCount = 0; ColCount < DataRead.Length; ColCount++)
                    {
                        BagelPriceListArray[RowCount, ColCount] = int.Parse(DataRead[ColCount]); //loop and read each column and store in array
                    }
                    RowCount++;
                }
                FileRead.Close();
            }
            catch (Exception Excep)
            {
                MessageBox.Show(Excep.Message);
            }
            return BagelPriceListArray;
        }

        //Event Handler to check bagel type and related size if avaiable 
        public void BagelSizeListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (BagelSizeListBox.SelectedIndex != -1)
            {
                if(StockInventoryArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex] == 0) //condition to check if stock is available
                {
                    MessageBox.Show("OOPS! Product Out of Stock" + "\n" + "Please select another Item", "Stock Alert", 
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    BagelSizeListBox.ClearSelected();
                    PriceLabel2.Text = "";
                }
                else // popluate price box if stock is avaliables
                {
                    BagelPrice = BagelPriceListArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex];
                    PriceLabel2.Text = BagelPrice.ToString("C2");
                }
            }
        }

        //Event handler to add items to cart based on available stock
        public void AddToCartButton_Click(object sender, EventArgs e)
        {
            
            QuantityStock = Convert.ToInt32(UpDownOperator.Value); //store quantity in variable
            SummaryQuantity1 += QuantityStock; //increment quantity on each order
            
            if (BagelTypeListBox.SelectedIndex != -1)
            {
                if(BagelSizeListBox.SelectedIndex != -1 )
                {
                    if(QuantityStock > 0) //condition to check for available stocks
                    {
                        if (QuantityStock > StockInventoryArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex])
                        {
                            MessageBox.Show("OOPS! Only "+ 
                                StockInventoryArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex]+
                                " Avaiable in Stock Currently"+"\n"+"SORRY :(", "Stock Update",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            UpDownOperator.Value = StockInventoryArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex];
                        }
                        else //add items to cart list view and receipt
                        {
                            
                            ItemTotal = BagelPrice * QuantityStock;
                            ListViewItem cart = new ListViewItem(BagelTypes[BagelTypeListBox.SelectedIndex]);
                            cart.SubItems.Add(BagelSize[BagelSizeListBox.SelectedIndex]);
                            cart.SubItems.Add(QuantityStock.ToString());
                            cart.SubItems.Add(ItemTotal.ToString("C2"));
                            BagelShowCartView.Items.Add(cart);
                            FinalPrice = ItemTotal + FinalPrice;
                            TotalPriceLabel2.Text = FinalPrice.ToString("C2");
                            TotalTransactionCreated.Add(BagelTypeListBox.SelectedIndex.ToString() + "|" +
                                BagelSizeListBox.SelectedIndex.ToString() + "|" + QuantityStock + "|" + ItemTotal);

                            MessageDisplay += QuantityStock + " " + BagelTypes[BagelTypeListBox.SelectedIndex] +
                                " " + BagelSize[BagelSizeListBox.SelectedIndex] + " = $" + ItemTotal+"\n";

                            //updating stock details
                            StockInventoryArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex] =
                                StockInventoryArray[BagelTypeListBox.SelectedIndex, BagelSizeListBox.SelectedIndex] - QuantityStock;
                            BagelTypeListBox.SelectedItems.Clear();
                            BagelSizeListBox.SelectedItems.Clear();
                            BagelSizeListBox.Enabled = false;
                            PriceLabel2.Text = "";
                            UpDownOperator.Value = 0;
                            QuantityStock = 0;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Add Atleast one doughnut to Proceed", "Proceed Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Select any Doughnut Size to Proceed", "Selection Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Select any Doughnut Type to Proceed", "Selection Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            
        }

        //Event habdler to exit the application
        private void ExitButton_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit the system",
                "BagelShop system", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //Event handler to generate sales report
        private void SalesReportButton_Click(object sender, EventArgs e)
        {
            
            SalesForm NewForm = new SalesForm(); //call sales form3
            NewForm.ShowDialog();
        }

        //Event handler to generate stock report file
        private void StockReportButton_Click(object sender, EventArgs e)
        {
            StreamWriter StockReportGenerator = File.CreateText("Bagel_Shop_Stock_Report.txt"); //Create a file in debug folder

            //add below lines in the file
            StockReportGenerator.WriteLine(" Stock report generated date: " + Currentdate.ToShortDateString()
                +"Time: "+ Currentdate.ToShortTimeString());
            StockReportGenerator.WriteLine("\n");
            StockReportGenerator.WriteLine("UPDATED STOCKS ARE SHOWN BELOW:\n");

            string FileInfo = string.Format("{0,-20}{1,-15}{2,-20}{3,-15}{4,-15}{5,-15}\n", 
                "Food Items", "Small", "Medium", "Regular", "Large", "Extra-large"); //formatting of the file with spacing

            for(int count=0;count<BagelTypes.Length;count++) //store the remaning stock with names in the varibles
            {
                FileInfo += String.Format("{0,-20}{1,-15}{2,-20}{3,-15}{4,-15}{5,-15}\n", BagelTypes[count],
                    StockInventoryArray[count, 0], StockInventoryArray[count, 1], StockInventoryArray[count, 2]
                    , StockInventoryArray[count, 3], StockInventoryArray[count, 4]);
            }
            StockReportGenerator.WriteLine($"{FileInfo}"); //Write to file
            StockReportGenerator.Close();

            MessageBox.Show("Stock Report Generated Successsfully", "Stock Report Generation",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        //Main Form Load
        private void MBSIMainForm_Load(object sender, EventArgs e)
        {
            TrxnLabel.Visible = false;
            BagelSizeListBox.Enabled = false;
        }

        //Method to generate random ID and return value
        private int RandomNumberGeneration()
        {
            Random RandomTN = new Random();
            int NewTransactionNumber = RandomTN.Next(10000, 99999);
            return NewTransactionNumber; //storing in varible to diplay in message box
            
        }

        //Event handler to display summary form and details
        private void SummaryButton_Click(object sender, EventArgs e)
        {
            SummaryMainForm NewForm = new SummaryMainForm();
            NewForm.SummaryValues(SummaryQuantity, SummaryTotal, SummaryTransactions, SummaryAvg);
            NewForm.Show();

        }

        //Event handler to check transaction number is unique
        private void CheckRandomNumberIsUnique(int NewTrxnNumber, string TransactionSummary)
        {
            string ValCheck = NewTrxnNumber.ToString();
            string[] CheckFile = File.ReadAllLines(TransactionSummary); //Read lines from the transaction file
            for(int each=0;each<CheckFile.Length;each++)
            {
                if (CheckFile[each].Contains(ValCheck)) //condition to check if same number exists
                {
                    CheckNum = true;
                    TrxnLabel.Visible=true;
                    TransactionNumberOutput = RandomNumberGeneration(); //regenerate number
                }
                else
                {
                    CheckNum = false;
                    TrxnLabel.Visible = false;
                }

            }
        }

        //Event handler to remove items in cart
        //private void RemoveButton_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        MessageDisplay = "";
        //        BagelType = BagelShowCartView.SelectedItems[0].SubItems[0].Text;
        //        BagelSizes = BagelShowCartView.SelectedItems[0].SubItems[1].Text;
        //        ReverseQuantity = int.Parse(BagelShowCartView.SelectedItems[0].SubItems[2].Text);
        //        ReverseAmount = decimal.Parse(BagelShowCartView.SelectedItems[0].SubItems[3].Text);
        //        try
        //        {
        //            FinalPrice -= ReverseAmount;
        //            BagelShowCartView.Items.Remove(BagelShowCartView.SelectedItems[0]);
        //            TotalPriceLabel2.Text = FinalPrice.ToString();
        //            BagelTypeIndex = Array.IndexOf(BagelTypes, BagelType);
        //            BagelSizeIndex = Array.IndexOf(BagelSize, BagelSizes);
        //            StockInventoryArray[BagelTypeIndex, BagelSizeIndex] =
        //                        StockInventoryArray[BagelTypeIndex, BagelSizeIndex] + ReverseQuantity;
        //            TotalTransactionCreated.RemoveAt(BagelTypeIndex);
        //        }
        //        catch (Exception Excep)
        //        {
        //            MessageBox.Show(Excep.Message);
        //        }
        //
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Please select an Option to Remove Item", "Remove Error",
        //            MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //    
        //}

        //Event handler to clear the order and cart
        private void ClearButton_Click(object sender, EventArgs e)
        {
            FinalPrice = 0;
            TotalTransactionCreated.Clear();
            BagelTypeListBox.ClearSelected();
            BagelSizeListBox.ClearSelected();
            UpDownOperator.Value = 0;
            PriceLabel2.Text = "";
            Array.Copy(TempStockInventoryArray, 0, StockInventoryArray, 0, StockInventoryArray.Length);
            BagelShowCartView.Items.Clear();
            TotalPriceLabel2.Text = "";
            MessageDisplay = "";
            SummaryQuantity1 = SummaryQuantity; ;
        }
        
        //Event handler to confirm the order
        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            if (File.Exists(TransactionSummary))
            {
                if(BagelShowCartView.Items.Count != 0)
                {
                    TransactionNumberOutput = RandomNumberGeneration(); //random numner generation
                    CheckRandomNumberIsUnique(TransactionNumberOutput, TransactionSummary); //check random number is unique
                    DialogResult ProceedResult = MessageBox.Show("\n" + "Do you wish to confirm your details? " +
                        "\n" + "Transaction Number: " + TransactionNumberOutput +
                        "\n" + "Transaction Timestamp: " + Currentdate.ToString() +
                        "\n" + MessageDisplay +
                        "\n" + "Total Price:  $" + FinalPrice, "Confirmation", MessageBoxButtons.OKCancel,
                        MessageBoxIcon.Information);

                    if (ProceedResult == DialogResult.OK)
                    {
                        try
                        {
                            //Storing and incr values for summary details
                            SummaryTransactions++;
                            SummaryTotal += FinalPrice;
                            SummaryAvg = SummaryTotal / SummaryTransactions;
                            SummaryQuantity = SummaryQuantity1;

                            Array.Copy(StockInventoryArray, 0, TempStockInventoryArray, 0, StockInventoryArray.Length); //copy array elements if OK
                           
                            StreamWriter TransactionSummaryDetails; //store transaction in file
                            TransactionSummaryDetails = File.AppendText(TransactionSummary);
                            for (int count = 0; count < TotalTransactionCreated.Count; count++)
                            {
                                int BagelTypeIndex = int.Parse((TotalTransactionCreated[count].Split('|'))[0]);
                                int BagelSizeIndex = int.Parse((TotalTransactionCreated[count].Split('|'))[1]);
                                int BagelQuantityIndex = int.Parse((TotalTransactionCreated[count].Split('|'))[2]);
                                int TotalPriceIndex = int.Parse((TotalTransactionCreated[count].Split('|'))[3]);
                                TransactionSummaryDetails.WriteLine(TransactionNumberOutput + " | " + Currentdate.ToString() + " | " +
                                    BagelTypes[BagelTypeIndex] + " | " + BagelSize[BagelSizeIndex] + " | "
                                    + BagelQuantityIndex + " | " + TotalPriceIndex);
                            }
                            TransactionSummaryDetails.Close();

                            //update stock array after confirm order
                            File.Delete(STOCKININVENTORYFILE);
                            if (!File.Exists(STOCKININVENTORYFILE))
                            {
                                var _File = File.CreateText(STOCKININVENTORYFILE);
                                _File.Dispose();
                            }
                            StreamWriter LatestSalesReport = File.AppendText(STOCKININVENTORYFILE);

                            for (int i = 0; i < ROWS_IN_FILE; i++)
                            {
                                comma = "";
                                for (int j = 0; j < COLS_IN_FILE; j++)
                                {
                                    LatestSalesReport.Write(comma);
                                    LatestSalesReport.Write(StockInventoryArray[i, j]);
                                    comma = ",";

                                }
                                LatestSalesReport.Write(Environment.NewLine);
                            }
                            LatestSalesReport.Close();

                            BagelTypeListBox.ClearSelected();
                            BagelSizeListBox.ClearSelected();
                            UpDownOperator.Value = 0;
                            PriceLabel2.Text = "";
                            FinalPrice = 0;
                            BagelShowCartView.Items.Clear();
                            TotalPriceLabel2.Text = "";
                            MessageDisplay = "";
                            TotalTransactionCreated.Clear();
                            //SummaryQuantity1 = 0;


                        }
                        catch (Exception Excep)
                        {
                            MessageBox.Show(Excep.Message);
                        }

                    }
                    else //ops to perform when cancel order
                    {
                        Array.Copy(TempStockInventoryArray, 0, StockInventoryArray, 0, StockInventoryArray.Length); //revert array elements
                        BagelShowCartView.Items.Clear();
                        TotalPriceLabel2.Text = "";
                        FinalPrice = 0;
                        MessageDisplay = "";
                        SummaryQuantity1 = SummaryQuantity;
                    }
                }
                else
                {
                    DialogResult ProceedResult = MessageBox.Show("\n" + "Please add Items to Cart to Proceed ", 
                        "Add Items to Cart", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                
            }
            else
            {
                StreamWriter NewFile = File.CreateText(TransactionSummary);
                NewFile.Close();
            }

                
        }

        //Event handler to search transaction details
        private void SearchButton_Click(object sender, EventArgs e)
        {
            SearchForm NewForm = new SearchForm();
            NewForm.Show();
        }

        private void BagelTypeListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            BagelSizeListBox.Enabled = true;
        }
        private void QuantityLabel1_Click(object sender, EventArgs e)
        {

        }

    }
}