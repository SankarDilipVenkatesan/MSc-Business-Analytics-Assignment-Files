﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//SUMMARY FORM OPS
namespace MyBagelShopAssignment
{
    public partial class SummaryMainForm : Form
    {
        public SummaryMainForm()
        {
            InitializeComponent();
        }

        //Event handler to exit the summary form
        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SummaryMainForm_Load(object sender, EventArgs e)
        {
           
        }

        //Event handler to display summary values
        public void SummaryValues(int val1, decimal val2, int val3, decimal val4)
        {
            TotalBagelSoldLabel1.Text = val1.ToString();
            TotalSaleValueLabel1.Text = val2.ToString("C2");
            TotalTnxlabel1.Text=val3.ToString();
            AvgTransactiosnLabel1.Text = val4.ToString("C2");
        }
    }
}
