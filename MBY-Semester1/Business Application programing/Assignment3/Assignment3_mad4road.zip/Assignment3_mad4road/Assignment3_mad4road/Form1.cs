/* Student Name: Dilip Venkatesan Sankar
 * Student ID: 22225743
 * Date: 06/11/2022
 * Assignment: 3
 * Assignment: Create a well-designed application for Mad4Money Corp called
 * Mad4Road that allows Customers to borrow money
 */

using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Transactions;
using System.Reflection.Emit;
using System.Text.RegularExpressions;
using System.DirectoryServices;

namespace Assignment3_mad4road
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            InvestementGroupBox.Visible = false;
            ClientDetailsGroupBox.Visible = false;
            SearchGroupBox.Visible = false;
            SummaryGroupBox.Visible = false;
            ProceedButton.Enabled = false;
            LogoPictureBox1.Visible = false;
            RoadSideAssitanceLabel.Visible = false;
        }

        //Initializing global variables
        int InvestementAmount, TransactionNumberOutput=0;
        int MaxLoginAttempts = 2, NumberOfLogins = 1, RemainingLogins = 2;
        decimal MonthlyInterest1, TotalInterest1, TotalAmount1,
            MonthlyInterest2, TotalInterest2, TotalAmount2,
            MonthlyInterest3, TotalInterest3, TotalAmount3,
            MonthlyInterest4, TotalInterest4, TotalAmount4,
            MonthlyInterest5, TotalInterest5, TotalAmount5,
            MonthlyInterest6, TotalInterest6, TotalAmount6,
            MonthlyInterest7, TotalInterest7, TotalAmount7,
            MonthlyInterest8, TotalInterest8, TotalAmount8,
            MonthlyInterest9, TotalInterest9, TotalAmount9,
            MonthlyInterest10, TotalInterest10, TotalAmount10,
            MonthlyInterest11, TotalInterest11, TotalAmount11,
            MonthlyInterest12, TotalInterest12, TotalAmount12;
        const string LOANSTORAGE = "LoanDetails.txt";
        const string LOGINPASSWORD = "2Fast4U#";
        string HeaderDetails = "{0,-10}{1,-20}{2,-20:C2}{3,-20:C2}{4,-16:C2}";
        const string TERM1 = "1 Year", TERM2 = "3 Years", TERM3 = "5 Years", TERM4 = "7 Years";
        const int INTERESTYEAR1 = 1, INTERESTYEAR2 = 3, INTERESTYEAR3 = 5, INTERESTYEAR4 = 7;
        const int INTERESTMONTH1 = 12, INTERESTMONTH2 = 36, INTERESTMONTH3 = 60, INTERESTMONTH4 = 84;
        const string INTEREST1A = "6.00%", INTEREST2A = "6.50%", INTEREST3A = "7.00%", INTEREST4A = "7.50%";
        const string INTEREST1B = "8.00%", INTEREST2B = "8.50%", INTEREST3B = "9.00%", INTEREST4B = "9.50%";
        const string INTEREST1C = "8.50%", INTEREST2C = "8.75%", INTEREST3C = "9.10%", INTEREST4C = "9.25%";
        const decimal INTERESTRATE1 = 0.06m, INTERESTRATE2 = 0.065m, INTERESTRATE3 = 0.07m, INTERESTRATE4 = 0.075m;
        decimal INTERESTRATE5 = 0.08m, INTERESTRATE6 = 0.085m, INTERESTRATE7 = 0.09m, INTERESTRATE8 = 0.095m;
        decimal INTERESTRATE9 = 0.085m, INTERESTRATE10 = 0.0875m, INTERESTRATE11 = 0.091m, INTERESTRATE12 = 0.0925m;
        string TermFinal = "", InterestRateFinal = "";
        decimal MonthlyInterestFinal, TotalInterestFinal, TotalAmountFinal, NumberOfLoginBookings,AvgDurationOfLoansLB;
        decimal SummaryPrincipalAmount = 0, SummaryTotalInterestValue = 0;
        decimal TotalPrincipalAmountLB, TotalInterestValueLB, AvgAmountLB;
        int SelectionIndex = 0, AvgDuration, SummaryMonth;
        string SummaryYear = "", SearchTransacition = "", SearchEmail = "", SearchName = "", SearchCode = "", SearchPhone = "", SearchAmount = "", SearchYear = "", SearchInterest = "",
                        SearchMonthlyAmount = "", SearchTotalInterest = "", SearchTotalAmount = "", EmptyLine="";
        bool CheckStatus;
        
        //Event handler to validate password and login
        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (PasswordTB.Text==LOGINPASSWORD) //condition to check if password matched
            {
                InvestementGroupBox.Visible = true;
                PasswordTB.Clear();
                LoginGroupBox.Visible = false;
                SummaryGroupBox.Visible = true;
                SearchGroupBox.Visible = true;
                LogoPictureBox.Visible = false;
                LogoPictureBox1.Visible = true;
                ClientDetailsGroupBox.Visible = true;
            }
            else
            {
                if (NumberOfLogins == MaxLoginAttempts) //condition to exit if login attempt exceeded
                {
                    MessageBox.Show("Maximum retries exhausted","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                else //condition to increment attempt and provide a re-login
                {
                    NumberOfLogins++;
                    MessageBox.Show("Incorrect Password" + "\n" +"Number of attempts left:" + --RemainingLogins, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    PasswordTB.Clear();
                }
            }
        }

        //Method1 to calculate total repayment and return value
        private decimal TotalRepaymentCalculation(decimal InvestmentAmount, decimal interest ,decimal years)
        {
            for (int count = 0; count < years; count++)
            {
                InvestmentAmount += (interest * InvestmentAmount);
            }
            return Math.Round(InvestmentAmount,2); //return output to variable
        }

        //Method2 to calculate total interest and return value
        private decimal TotalInterestCalcualtion(decimal InvestmentAmount, decimal TotalAmount)
        {
            return Math.Round(TotalAmount - InvestmentAmount, 2); //return output to variable 
        }
        
        //Method3 to calculate monthly interest and return value
        private decimal MonthlyInterest(decimal TotalAmount, int months)
        {
            return Math.Round(TotalAmount / months,2); //return output to variable
        }

        //Method4 to generate random ID and return value
        private string RandomNumberGeneration()
        {
            Random RandomTN = new Random();
            int NewTransactionNumber = RandomTN.Next(10000, 99999);
            TransactionNumberOutput = NewTransactionNumber; //storing in varible to diplay in message box
            return NewTransactionNumber.ToString(); //return output to variable
        }

        //Event handler to display loan options
        private void DisplayButton_Click(object sender, EventArgs e)
        {
            //Condtion to check text box is empty and only numerical data is present
            if(InvestementAmountTB.Text == "" || Regex.IsMatch(InvestementAmountTB.Text, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("Please enter Loan amount in Numbers", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                InvestementAmount = int.Parse(InvestementAmountTB.Text);
                if (InvestementAmount < 10000) //condition to check if amount is less than 10000
                {
                    MessageBox.Show("Please enter an amount above 10000", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (InvestementAmount > 100000) //condition to check if amount is greater than 100000
                {
                    MessageBox.Show("Please enter an amount below 100000", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    try
                    {
                        if (InvestementAmount >= 10000 && InvestementAmount < 40000) //If condition when principal in less than 40000
                        {
                            //Calculation for monthly interest, total interest and total amount for 1 Year
                            TotalAmount1 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE1, INTERESTYEAR1);
                            TotalInterest1 = TotalInterestCalcualtion(InvestementAmount, TotalAmount1);
                            MonthlyInterest1 = MonthlyInterest(TotalAmount1, INTERESTMONTH1);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM1,
                                INTEREST1A, MonthlyInterest1, TotalInterest1, TotalAmount1));

                            //Calculation for monthly interest, total interest and total amount for 3 Year
                            TotalAmount2 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE2, INTERESTYEAR2);
                            TotalInterest2 = TotalInterestCalcualtion(InvestementAmount, TotalAmount2);
                            MonthlyInterest2 = MonthlyInterest(TotalAmount2, INTERESTMONTH2);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM2,
                                INTEREST2A, MonthlyInterest2, TotalInterest2, TotalAmount2));

                            //Calculation for monthly interest, total interest and total amount for 5 Year
                            TotalAmount3 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE3, INTERESTYEAR3);
                            TotalInterest3 = TotalInterestCalcualtion(InvestementAmount, TotalAmount3);
                            MonthlyInterest3 = MonthlyInterest(TotalAmount3, INTERESTMONTH3);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM3,
                                INTEREST3A, MonthlyInterest3, TotalInterest3, TotalAmount3));

                            //Calculation for monthly interest, total interest and total amount for 7 Year
                            TotalAmount4 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE4, INTERESTYEAR4);
                            TotalInterest4 = TotalInterestCalcualtion(InvestementAmount, TotalAmount4);
                            MonthlyInterest4 = MonthlyInterest(TotalAmount4, INTERESTMONTH4);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM4,
                                INTEREST4A, MonthlyInterest4, TotalInterest4, TotalAmount4));
                        }
                        //condition if amount is greater than or equal to 4000 and less than 80000
                        else if ((InvestementAmount >= 40000) && (InvestementAmount < 80000))
                        {
                            //Calculation for monthly interest, total interest and total amount for 1 Year
                            TotalAmount5 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE5, INTERESTYEAR1);
                            TotalInterest5 = TotalInterestCalcualtion(InvestementAmount, TotalAmount5);
                            MonthlyInterest5 = MonthlyInterest(TotalAmount5, INTERESTMONTH1);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM1,
                                INTEREST1B, MonthlyInterest5, TotalInterest5, TotalAmount5));

                            //Calculation for monthly interest, total interest and total amount for 3 Year
                            TotalAmount6 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE6, INTERESTYEAR2);
                            TotalInterest6 = TotalInterestCalcualtion(InvestementAmount, TotalAmount6);
                            MonthlyInterest6 = MonthlyInterest(TotalAmount6, INTERESTMONTH2);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM2,
                                INTEREST2B, MonthlyInterest6, TotalInterest6, TotalAmount6));

                            //Calculation for monthly interest, total interest and total amount for 5 Year
                            TotalAmount7 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE7, INTERESTYEAR3);
                            TotalInterest7 = TotalInterestCalcualtion(InvestementAmount, TotalAmount7);
                            MonthlyInterest7 = MonthlyInterest(TotalAmount7, INTERESTMONTH3);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM3,
                                INTEREST3B, MonthlyInterest7, TotalInterest7, TotalAmount7));

                            //Calculation for monthly interest, total interest and total amount for 7 Year
                            TotalAmount8 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE8, INTERESTYEAR4);
                            TotalInterest8 = TotalInterestCalcualtion(InvestementAmount, TotalAmount8);
                            MonthlyInterest8 = MonthlyInterest(TotalAmount8, INTERESTMONTH4);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM3,
                                INTEREST4B, MonthlyInterest8, TotalInterest8, TotalAmount8));
                        }
                        //condition if amount is greater than or equal to 80000 and less than 100000
                        else if ((InvestementAmount >= 80000) && (InvestementAmount <= 100000))
                        {
                            //Calculation for monthly interest, total interest and total amount for 1 Year
                            TotalAmount9 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE9, INTERESTYEAR1);
                            TotalInterest9 = TotalInterestCalcualtion(InvestementAmount, TotalAmount9);
                            MonthlyInterest9 = MonthlyInterest(TotalAmount9, INTERESTMONTH1);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM1,
                                INTEREST1C, MonthlyInterest9, TotalInterest9, TotalAmount9));

                            //Calculation for monthly interest, total interest and total amount for 3 Year
                            TotalAmount10 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE10, INTERESTYEAR2);
                            TotalInterest10 = TotalInterestCalcualtion(InvestementAmount, TotalAmount10);
                            MonthlyInterest10 = MonthlyInterest(TotalAmount10, INTERESTMONTH2);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM2,
                                INTEREST2C, MonthlyInterest10, TotalInterest10, TotalAmount10));

                            //Calculation for monthly interest, total interest and total amount for 5 Year
                            TotalAmount11 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE11, INTERESTYEAR3);
                            TotalInterest11 = TotalInterestCalcualtion(InvestementAmount, TotalAmount11);
                            MonthlyInterest11 = MonthlyInterest(TotalAmount11, INTERESTMONTH3);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM3,
                                INTEREST3C, MonthlyInterest11, TotalInterest11, TotalAmount11));

                            //Calculation for monthly interest, total interest and total amount for 7 Year
                            TotalAmount12 = TotalRepaymentCalculation(InvestementAmount, INTERESTRATE12, INTERESTYEAR4);
                            TotalInterest12 = TotalInterestCalcualtion(InvestementAmount, TotalAmount12);
                            MonthlyInterest12 = MonthlyInterest(TotalAmount12, INTERESTMONTH4);

                            CalculationListBox.Items.Add(string.Format(HeaderDetails, TERM4,
                                INTEREST4C, MonthlyInterest12, TotalInterest12, TotalAmount12));
                        }
                        ProceedButton.Enabled = true;
                        DisplayButton.Enabled = false;
                    }
                    catch (Exception CalcIssue)//Exception for calculation issue
                    {
                        MessageBox.Show(CalcIssue.Message);
                    }
                }
            
            }     
        }

        //Event handler to proceed with the selected loan term
        private void ProceedButton_Click(object sender, EventArgs e)
        {
            if (CalculationListBox.SelectedIndex != -1) //switch case statement index selection from the list box
            {
                //Execute If block when amount is less than 40000 and assign variables based on selected option
                if (InvestementAmount >= 10000 && InvestementAmount < 40000) 
                {
                    SelectionIndex = CalculationListBox.SelectedIndex;
                    switch (SelectionIndex)
                    {
                        case 0:
                            TermFinal = TERM1; InterestRateFinal = INTEREST1A;
                            MonthlyInterestFinal = MonthlyInterest1; TotalInterestFinal = TotalInterest1;
                            TotalAmountFinal = TotalAmount1; break;
                        case 1:
                            TermFinal = TERM2; InterestRateFinal = INTEREST2A;
                            MonthlyInterestFinal = MonthlyInterest2; TotalInterestFinal = TotalInterest2;
                            TotalAmountFinal = TotalAmount2; break;
                        case 2:
                            TermFinal = TERM3; InterestRateFinal = INTEREST3A;
                            MonthlyInterestFinal = MonthlyInterest3; TotalInterestFinal = TotalInterest3;
                            TotalAmountFinal = TotalAmount3; break;
                        case 3:
                            TermFinal = TERM4; InterestRateFinal = INTEREST4A;
                            MonthlyInterestFinal = MonthlyInterest4; TotalInterestFinal = TotalInterest4;
                            TotalAmountFinal = TotalAmount4; break;
                    }
                }
                //Execute else if block if amount is >=40000 and <80000 and assign variables based on selected option
                else if ((InvestementAmount >= 40000) && (InvestementAmount < 80000))
                {
                    SelectionIndex = CalculationListBox.SelectedIndex;
                    switch (SelectionIndex)
                    {
                        case 0:
                            TermFinal = TERM1; InterestRateFinal = INTEREST1B;
                            MonthlyInterestFinal = MonthlyInterest5; TotalInterestFinal = TotalInterest5;
                            TotalAmountFinal = TotalAmount5; break;
                        case 1:
                            TermFinal = TERM2; InterestRateFinal = INTEREST2B;
                            MonthlyInterestFinal = MonthlyInterest6; TotalInterestFinal = TotalInterest6;
                            TotalAmountFinal = TotalAmount6; break;
                        case 2:
                            TermFinal = TERM3; InterestRateFinal = INTEREST3B;
                            MonthlyInterestFinal = MonthlyInterest7; TotalInterestFinal = TotalInterest7;
                            TotalAmountFinal = TotalAmount7; break;
                        case 3:
                            TermFinal = TERM4; InterestRateFinal = INTEREST4B;
                            MonthlyInterestFinal = MonthlyInterest8; TotalInterestFinal = TotalInterest8;
                            TotalAmountFinal = TotalAmount8; break;
                    }
                }
                //Execute else block when amount is greater than 80000and assign variables based on selected option
                else if ((InvestementAmount >= 80000) && (InvestementAmount <= 100000)) 
                {
                    SelectionIndex = CalculationListBox.SelectedIndex;
                    switch (SelectionIndex)
                    {
                        case 0:
                            TermFinal = TERM1; InterestRateFinal = INTEREST1C;
                            MonthlyInterestFinal = MonthlyInterest9; TotalInterestFinal = TotalInterest9;
                            TotalAmountFinal = TotalAmount9; break;
                        case 1:
                            TermFinal = TERM2; InterestRateFinal = INTEREST2C;
                            MonthlyInterestFinal = MonthlyInterest10; TotalInterestFinal = TotalInterest10;
                            TotalAmountFinal = TotalAmount10; break;
                        case 2:
                            TermFinal = TERM3; InterestRateFinal = INTEREST3C;
                            MonthlyInterestFinal = MonthlyInterest11; TotalInterestFinal = TotalInterest11;
                            TotalAmountFinal = TotalAmount11; break;
                        case 3:
                            TermFinal = TERM4; InterestRateFinal = INTEREST4C;
                            MonthlyInterestFinal = MonthlyInterest12; TotalInterestFinal = TotalInterest12;
                            TotalAmountFinal = TotalAmount12; break;
                    }
                }
                //Call below method to generate random transaction ID
                TransactionNumberLabelOP.Text =RandomNumberGeneration();
                //ops to perform after proceed button is clicked
                InvestementGroupBox.Enabled = false;
                ClientDetailsGroupBox.Visible = true;
            }
            else //else block is executed when no option is selected
            {
                MessageBox.Show("Please Select an an option to Proceed",
                "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        //Event handler to enter client details and store detials in text file
        private void SubmitButton_Click(object sender, EventArgs e)
        {
            //condition to check if all the client dtails has been entered
            if (TransactionNumberLabelOP.Text != "")
            {
                if (ClientNameTB.Text != "" || PostalCodeTB.Text != "" || PhoneNumberTB.Text != "" || EmailTB.Text != "")
                {
                    if (ClientNameTB.Text != "")
                    {
                        if (PostalCodeTB.Text != "" && PostalCodeTB.Text.Length == 8)
                        {
                            if (PhoneNumberTB.Text != "" && PhoneNumberTB.Text.Length == 9)
                            {
                                if (EmailTB.Text != "" && EmailTB.Text.Contains("@") && EmailTB.Text.Contains("."))
                                {
                                    //Obtaining user confirmation before storing vaules in text file
                                    DialogResult ProceedResult = MessageBox.Show("\n" + "Do you wish to confirm your details? " +
                                "\n" + "Client's Name: " + ClientNameTB.Text +
                                "\n" + "Postal Code: " + PostalCodeTB.Text +
                                "\n" + "Phone No: " + PhoneNumberTB.Text +
                                "\n" + "E-mail ID: " + EmailTB.Text +
                                "\n" + "Transaction No: " + TransactionNumberOutput.ToString() +
                                "\n" + "Principal Amount: " + InvestementAmount.ToString() +
                                "\n" + "Loan Term: " + TermFinal.ToString() +
                                "\n" + "Interest Rate: " + InterestRateFinal.ToString() +
                                "\n" + "Monthly Repayment: " + MonthlyInterestFinal.ToString() +
                                "\n" + "Total Interest: " + TotalInterestFinal.ToString() +
                                "\n" + "Total Amount: " + TotalAmountFinal.ToString(), "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                                    //if condition block execute when OK option is selected
                                    if (ProceedResult == DialogResult.OK)
                                    {
                                        try
                                        {
                                            //Open file and append details to text file
                                            StreamWriter TransactionFile;
                                            TransactionFile = File.AppendText(LOANSTORAGE);
                                            TransactionFile.WriteLine(TransactionNumberLabelOP.Text);
                                            TransactionFile.WriteLine(EmailTB.Text);
                                            TransactionFile.WriteLine(ClientNameTB.Text);
                                            TransactionFile.WriteLine(PostalCodeTB.Text);
                                            TransactionFile.WriteLine(PhoneNumberTB.Text);
                                            TransactionFile.WriteLine(InvestementAmount.ToString());
                                            TransactionFile.WriteLine(TermFinal.ToString());
                                            TransactionFile.WriteLine(InterestRateFinal.ToString());
                                            TransactionFile.WriteLine(MonthlyInterestFinal.ToString());
                                            TransactionFile.WriteLine(TotalInterestFinal.ToString());
                                            TransactionFile.WriteLine(TotalAmountFinal.ToString()); ;
                                            TransactionFile.Write("\n"); //empty line for differentiation
                                            TransactionFile.Close();

                                            //Ops to perform after OK button is pressed
                                            TransactionNumberLabelOP.Text = "";
                                            ClientNameTB.Text = "";
                                            PostalCodeTB.Text = "";
                                            PhoneNumberTB.Text = "";
                                            EmailTB.Text = "";
                                            InvestementAmountTB.Text = "";
                                            CalculationListBox.Items.Clear();
                                            ProceedButton.Enabled = false;
                                            DisplayButton.Enabled = true;
                                            InvestementGroupBox.Enabled = true;
                                            TransactionNumberLabelOP.Text = "";
                                            ClientNameTB.Text = "";
                                            PostalCodeTB.Text = "";
                                            PhoneNumberTB.Text = "";
                                            EmailTB.Text = "";
                                            SummaryGroupBox.Visible = true;
                                            SearchGroupBox.Visible = true;
                                        }
                                        //catch block execute when issue with file opening and writing
                                        catch (Exception e1)
                                        {
                                            MessageBox.Show(e1.Message);
                                        }
                                    }
                                    else //Execute else block when user selects cancel option and dealing with objection if users wants to modify selection
                                    {
                                        MessageBox.Show("Your transaction has been cancelled", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        TransactionNumberLabelOP.Text = "";
                                        CalculationListBox.Items.Clear();
                                        InvestementGroupBox.Enabled = true;
                                        ProceedButton.Enabled = false;
                                        DisplayButton.Enabled = true;
                                        SummaryGroupBox.Visible = true;
                                        SearchGroupBox.Visible = true;
                                    }
                                }
                                else //Execute else block when email address does not have "." or "@"
                                {
                                    DialogResult EmailResult = MessageBox.Show("Please enter a Valid Email address", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                            else //Execute else block when not a valid phone number
                            {
                                DialogResult PhoneNumberResult = MessageBox.Show("Please enter a Valid Phone number", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                        else //Execute else block when not a valid postal code
                        {
                            DialogResult PostalCodeResult = MessageBox.Show("Please enter a Valid Postal Code!", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else //Execute else block when no client name is entered
                    {
                        DialogResult ClientNameResule = MessageBox.Show("Please enter a Valid Client name", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else //Execute else block when no details are entered
                {
                    DialogResult AllDetailsResult = MessageBox.Show("Please enter the client details", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else //Execute else block when dealing with objection
            {
                DialogResult AllDetailsResult = MessageBox.Show("Cannot proceed without Transaction ID", "error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        //Event handler to check total company details and transaction
        private void SummaryButton_Click(object sender, EventArgs e)
        {
            if (!File.Exists(LOANSTORAGE)) //If block to check when LoanDetails file does not exists
            {
                MessageBox.Show("Transaction file does not exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            if (new FileInfo(LOANSTORAGE).Length != 0) //Execute if block when LoanDetails file exists with entries
            {
                StreamReader ReadData;
                try
                {
                    ReadData = File.OpenText("LoanDetails.txt"); //Open text file and read data
                    while (!ReadData.EndOfStream)
                    {
                        NumberOfLoginBookings++;
                        for (int SummarytIncr=0; SummarytIncr < 5; SummarytIncr++)
                        {
                            ReadData.ReadLine(); //Iterate to read first five lines
                        }
                        SummaryPrincipalAmount = decimal.Parse(ReadData.ReadLine()); //Reading Principal amount
                        SummaryYear = ReadData.ReadLine(); //Reading Months
                        if (SummaryYear == TERM1)
                        {
                            SummaryMonth = INTERESTMONTH1; //12 months
                        }
                        else if (SummaryYear == TERM2) 
                        {
                            SummaryMonth = INTERESTMONTH2; //36 months
                        }
                        else if (SummaryYear == TERM3)
                        {
                            SummaryMonth = INTERESTMONTH3; //60 months
                        }
                        else if (SummaryYear == TERM4)
                        {
                            SummaryMonth = INTERESTMONTH4; //84 months
                        }
                        ReadData.ReadLine(); //Reading Interest rate
                        ReadData.ReadLine(); //Reading Monthly repayment
                        SummaryTotalInterestValue = decimal.Parse(ReadData.ReadLine()); //Reading Total interest
                        ReadData.ReadLine(); //Reading Total amount
                        ReadData.ReadLine(); //Reading empty line

                        //Calculation and Increment values when new entries append to text file
                        TotalPrincipalAmountLB += SummaryPrincipalAmount;
                        TotalInterestValueLB += SummaryTotalInterestValue;
                        AvgDuration += SummaryMonth;
                        AvgAmountLB = TotalPrincipalAmountLB / NumberOfLoginBookings;
                        AvgDurationOfLoansLB = AvgDuration / NumberOfLoginBookings;
                    }
                    ReadData.Close(); //close file after reading
                    //displaying the values in labels after calculation when summary button is pressed 
                    TotalAmountBorrowedLabel.Text = TotalPrincipalAmountLB.ToString("C2");
                    TotalInterestOccuring.Text = TotalInterestValueLB.ToString("C2");
                    AverageAmount.Text = AvgAmountLB.ToString("C2");
                    AverageDuration.Text = AvgDurationOfLoansLB.ToString();
                    SummaryButton.Enabled = false;
                }
                catch (Exception SummaryExpection) //Execute catch block when not able to open file to read contents
                {
                    MessageBox.Show(SummaryExpection.Message);
                }
            }
            else if (new FileInfo(LOANSTORAGE).Length == 0) //Execute else if block when LoanDetails file is empty
            {
                MessageBox.Show("No New transacions", "Summary Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //event handler to search old transactions based on transaction number and email ID
        private void SearchButton_Click(object sender, EventArgs e)  
        {
            if (SearchTextBox.Text == "") //Execute if condition when textbox is empty
            {
                MessageBox.Show("Please enter email ID or transaction number", "Details", MessageBoxButtons.OK,
                     MessageBoxIcon.Error);
            }
            else
            {
                StreamReader SearchData;
                try
                {
                    SearchData = File.OpenText("LoanDetails.txt"); //Open text file and read data
                    while (!SearchData.EndOfStream) //read all the lines in the file till enf od file
                    {
                        SearchTransacition = SearchData.ReadLine(); //Reading transaction number
                        SearchEmail = SearchData.ReadLine(); //Reading email id
                        SearchName = SearchData.ReadLine(); //Reading name
                        SearchCode = SearchData.ReadLine(); //Reading code
                        SearchPhone =  SearchData.ReadLine(); //Reading phone
                        SearchAmount =  SearchData.ReadLine(); //Reading amount
                        SearchYear =  SearchData.ReadLine(); //Reading year
                        SearchInterest =  SearchData.ReadLine(); //Reading interest
                        SearchMonthlyAmount =  SearchData.ReadLine(); //Reading monthly repayment
                        SearchTotalInterest =  SearchData.ReadLine(); //Reading total interest
                        SearchTotalAmount =  SearchData.ReadLine(); //Reading total amount
                        EmptyLine = SearchData.ReadLine(); 

                        if ((EmailRadioButton.Checked) && (SearchTextBox.Text == SearchEmail) && (SearchTextBox.Text.Contains(".")) && (SearchTextBox.Text.Contains("@")))
                        {
                            CheckStatus = true; // return true when entered and file email address matchs for search condition

                        }
                        else if ((TransactionRadioButton.Checked) && (SearchTextBox.Text == SearchTransacition))
                        {
                            CheckStatus = true; //return true when entered and file transaction number match for search condition

                        }

                        if (CheckStatus == true) //read lines from file and display in list box
                        {
                            SearchResultsListBox.Items.Add("Trasaction #: "+SearchTransacition); //transaction number
                            SearchResultsListBox.Items.Add("Email ID : "+SearchEmail); //email id
                            SearchResultsListBox.Items.Add("Name: "+SearchName); //name
                            SearchResultsListBox.Items.Add("EIR Code: "+ SearchCode); //code
                            SearchResultsListBox.Items.Add("Phone #: "+ SearchPhone); //phone
                            SearchResultsListBox.Items.Add("Principal Amount: "+ SearchAmount); //amount
                            SearchResultsListBox.Items.Add("Tenure: "+ SearchYear); //year
                            SearchResultsListBox.Items.Add("Interest Rate: "+ SearchInterest); //interest
                            SearchResultsListBox.Items.Add("Monthly Interest: "+ SearchMonthlyAmount); //monthly repayment
                            SearchResultsListBox.Items.Add("Total Interest: "+ SearchTotalInterest); //total interest
                            SearchResultsListBox.Items.Add("Final Amount: "+ SearchTotalAmount); //total amount
                            SearchResultsListBox.Items.Add(EmptyLine);  //empty line
                            CheckStatus = false;
                        }
                    }  
                    SearchButton.Enabled = false;
                    SearchData.Close();
                    //if condition executes to check if no match condition and list box is empty
                    if (SearchResultsListBox.Items.Count == 0)
                    {
                        MessageBox.Show("No records found", "No records", MessageBoxButtons.OK,
                                 MessageBoxIcon.Information);
                        SearchButton.Enabled = true;
                    }
                }
                catch (Exception SearchError) //execute catch box when not able to open file to read contents
                {
                    MessageBox.Show(SearchError.Message);
                }
            }
            
        }

        //Event handler for Road side assistance and diplays label
        private void CalculationListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CalculationListBox.SelectedIndex >= 2)
            {
                RoadSideAssitanceLabel.Visible = true;
            }
            else
            {
                RoadSideAssitanceLabel.Visible = false;
            }
        }

        //Event hander to clear search history
        private void SearchClearButton_Click(object sender, EventArgs e)
        {
            SearchTextBox.Clear();
            SearchResultsListBox.Items.Clear();
            SearchButton.Enabled = true;
            
        }

        //Event handler to clear all contents from the CalculationListBox
        private void ClearButton_Click(object sender, EventArgs e)
        {
            InvestementAmountTB.Clear();
            CalculationListBox.ClearSelected();
            CalculationListBox.Items.Clear();
            ProceedButton.Enabled = false;
            DisplayButton.Enabled = true;
        }
        
        //Event handler to exit the application
        private void ExitButton_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to exit the system",
                "Ordering system", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}