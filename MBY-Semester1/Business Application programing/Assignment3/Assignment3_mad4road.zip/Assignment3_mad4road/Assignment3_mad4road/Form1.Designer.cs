﻿namespace Assignment3_mad4road
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.LoginGroupBox = new System.Windows.Forms.GroupBox();
            this.LoginButton = new System.Windows.Forms.Button();
            this.PasswordTB = new System.Windows.Forms.TextBox();
            this.InvestementGroupBox = new System.Windows.Forms.GroupBox();
            this.RoadSideAssitanceLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CalculationPanel = new System.Windows.Forms.Panel();
            this.TermLB = new System.Windows.Forms.Label();
            this.InterestRateLB = new System.Windows.Forms.Label();
            this.MonthlyInterestLB = new System.Windows.Forms.Label();
            this.TotalInterestLB = new System.Windows.Forms.Label();
            this.TotalAmountLB = new System.Windows.Forms.Label();
            this.CalculationListBox = new System.Windows.Forms.ListBox();
            this.DisplayButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ProceedButton = new System.Windows.Forms.Button();
            this.InvestementAmountTB = new System.Windows.Forms.TextBox();
            this.InvestementLabel = new System.Windows.Forms.Label();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            this.LogoPictureBox1 = new System.Windows.Forms.PictureBox();
            this.ClientDetailsGroupBox = new System.Windows.Forms.GroupBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.TransactionDetailsPanel = new System.Windows.Forms.Panel();
            this.TransactionDetailsLabel = new System.Windows.Forms.Label();
            this.SubmitPanel = new System.Windows.Forms.Panel();
            this.TransactionNumberLabel = new System.Windows.Forms.Label();
            this.ClientNameLabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PostalCodeLabel = new System.Windows.Forms.Label();
            this.PhoneNumberLabel = new System.Windows.Forms.Label();
            this.EmailTB = new System.Windows.Forms.TextBox();
            this.PhoneNumberTB = new System.Windows.Forms.TextBox();
            this.PostalCodeTB = new System.Windows.Forms.TextBox();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.TransactionNumberLabelOP = new System.Windows.Forms.Label();
            this.ClientNameTB = new System.Windows.Forms.TextBox();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SearchResultsLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SearchClearButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchTextBox = new System.Windows.Forms.TextBox();
            this.EmailRadioButton = new System.Windows.Forms.RadioButton();
            this.TransactionRadioButton = new System.Windows.Forms.RadioButton();
            this.SearchResultsListBox = new System.Windows.Forms.ListBox();
            this.SummaryListBox = new System.Windows.Forms.ListBox();
            this.SummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.SummaryPanel = new System.Windows.Forms.Panel();
            this.SummaryLabel = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TotalAmountLabel = new System.Windows.Forms.Label();
            this.TotalInterestOccuring = new System.Windows.Forms.Label();
            this.AverageDuration = new System.Windows.Forms.Label();
            this.AverageAmount = new System.Windows.Forms.Label();
            this.TotalAmountBorrowedLabel = new System.Windows.Forms.Label();
            this.SummaryButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LoginGroupBox.SuspendLayout();
            this.InvestementGroupBox.SuspendLayout();
            this.CalculationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox1)).BeginInit();
            this.ClientDetailsGroupBox.SuspendLayout();
            this.TransactionDetailsPanel.SuspendLayout();
            this.SubmitPanel.SuspendLayout();
            this.SearchGroupBox.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SummaryGroupBox.SuspendLayout();
            this.SummaryPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoginGroupBox
            // 
            this.LoginGroupBox.BackColor = System.Drawing.Color.LightBlue;
            this.LoginGroupBox.Controls.Add(this.LoginButton);
            this.LoginGroupBox.Controls.Add(this.PasswordTB);
            this.LoginGroupBox.Location = new System.Drawing.Point(377, 258);
            this.LoginGroupBox.Name = "LoginGroupBox";
            this.LoginGroupBox.Size = new System.Drawing.Size(326, 131);
            this.LoginGroupBox.TabIndex = 1;
            this.LoginGroupBox.TabStop = false;
            this.LoginGroupBox.Text = "       Please Enter Password to login";
            // 
            // LoginButton
            // 
            this.LoginButton.Location = new System.Drawing.Point(107, 84);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(112, 34);
            this.LoginButton.TabIndex = 1;
            this.LoginButton.Text = "Login";
            this.LoginButton.UseVisualStyleBackColor = true;
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // PasswordTB
            // 
            this.PasswordTB.Location = new System.Drawing.Point(83, 47);
            this.PasswordTB.Name = "PasswordTB";
            this.PasswordTB.Size = new System.Drawing.Size(150, 31);
            this.PasswordTB.TabIndex = 0;
            this.PasswordTB.UseSystemPasswordChar = true;
            // 
            // InvestementGroupBox
            // 
            this.InvestementGroupBox.BackColor = System.Drawing.Color.LemonChiffon;
            this.InvestementGroupBox.Controls.Add(this.RoadSideAssitanceLabel);
            this.InvestementGroupBox.Controls.Add(this.label2);
            this.InvestementGroupBox.Controls.Add(this.CalculationPanel);
            this.InvestementGroupBox.Controls.Add(this.CalculationListBox);
            this.InvestementGroupBox.Controls.Add(this.DisplayButton);
            this.InvestementGroupBox.Controls.Add(this.ClearButton);
            this.InvestementGroupBox.Controls.Add(this.ProceedButton);
            this.InvestementGroupBox.Controls.Add(this.InvestementAmountTB);
            this.InvestementGroupBox.Controls.Add(this.InvestementLabel);
            this.InvestementGroupBox.Location = new System.Drawing.Point(24, 21);
            this.InvestementGroupBox.Name = "InvestementGroupBox";
            this.InvestementGroupBox.Size = new System.Drawing.Size(628, 368);
            this.InvestementGroupBox.TabIndex = 2;
            this.InvestementGroupBox.TabStop = false;
            // 
            // RoadSideAssitanceLabel
            // 
            this.RoadSideAssitanceLabel.AutoSize = true;
            this.RoadSideAssitanceLabel.BackColor = System.Drawing.Color.Chartreuse;
            this.RoadSideAssitanceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RoadSideAssitanceLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.RoadSideAssitanceLabel.Location = new System.Drawing.Point(6, 304);
            this.RoadSideAssitanceLabel.Name = "RoadSideAssitanceLabel";
            this.RoadSideAssitanceLabel.Size = new System.Drawing.Size(263, 52);
            this.RoadSideAssitanceLabel.TabIndex = 22;
            this.RoadSideAssitanceLabel.Text = "Free AA road side assitance\r\navailable for this load period ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(451, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 25);
            this.label2.TabIndex = 23;
            // 
            // CalculationPanel
            // 
            this.CalculationPanel.BackColor = System.Drawing.Color.LightBlue;
            this.CalculationPanel.Controls.Add(this.TermLB);
            this.CalculationPanel.Controls.Add(this.InterestRateLB);
            this.CalculationPanel.Controls.Add(this.MonthlyInterestLB);
            this.CalculationPanel.Controls.Add(this.TotalInterestLB);
            this.CalculationPanel.Controls.Add(this.TotalAmountLB);
            this.CalculationPanel.Location = new System.Drawing.Point(17, 71);
            this.CalculationPanel.Name = "CalculationPanel";
            this.CalculationPanel.Size = new System.Drawing.Size(598, 70);
            this.CalculationPanel.TabIndex = 22;
            // 
            // TermLB
            // 
            this.TermLB.AutoSize = true;
            this.TermLB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TermLB.Location = new System.Drawing.Point(3, 23);
            this.TermLB.Name = "TermLB";
            this.TermLB.Size = new System.Drawing.Size(54, 25);
            this.TermLB.TabIndex = 6;
            this.TermLB.Text = "Term";
            // 
            // InterestRateLB
            // 
            this.InterestRateLB.AutoSize = true;
            this.InterestRateLB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.InterestRateLB.Location = new System.Drawing.Point(77, 7);
            this.InterestRateLB.Name = "InterestRateLB";
            this.InterestRateLB.Size = new System.Drawing.Size(83, 50);
            this.InterestRateLB.TabIndex = 10;
            this.InterestRateLB.Text = "Interest \r\nRate";
            // 
            // MonthlyInterestLB
            // 
            this.MonthlyInterestLB.AutoSize = true;
            this.MonthlyInterestLB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MonthlyInterestLB.Location = new System.Drawing.Point(178, 7);
            this.MonthlyInterestLB.Name = "MonthlyInterestLB";
            this.MonthlyInterestLB.Size = new System.Drawing.Size(114, 50);
            this.MonthlyInterestLB.TabIndex = 9;
            this.MonthlyInterestLB.Text = "Monthly\r\n Repayment";
            // 
            // TotalInterestLB
            // 
            this.TotalInterestLB.AutoSize = true;
            this.TotalInterestLB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalInterestLB.Location = new System.Drawing.Point(336, 7);
            this.TotalInterestLB.Name = "TotalInterestLB";
            this.TotalInterestLB.Size = new System.Drawing.Size(78, 50);
            this.TotalInterestLB.TabIndex = 8;
            this.TotalInterestLB.Text = "Total \r\nInterest\r\n";
            // 
            // TotalAmountLB
            // 
            this.TotalAmountLB.AutoSize = true;
            this.TotalAmountLB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TotalAmountLB.Location = new System.Drawing.Point(465, 7);
            this.TotalAmountLB.Name = "TotalAmountLB";
            this.TotalAmountLB.Size = new System.Drawing.Size(81, 50);
            this.TotalAmountLB.TabIndex = 7;
            this.TotalAmountLB.Text = "Total \r\nAmount";
            // 
            // CalculationListBox
            // 
            this.CalculationListBox.FormattingEnabled = true;
            this.CalculationListBox.ItemHeight = 25;
            this.CalculationListBox.Location = new System.Drawing.Point(17, 147);
            this.CalculationListBox.Name = "CalculationListBox";
            this.CalculationListBox.Size = new System.Drawing.Size(598, 154);
            this.CalculationListBox.TabIndex = 0;
            this.CalculationListBox.SelectedIndexChanged += new System.EventHandler(this.CalculationListBox_SelectedIndexChanged);
            // 
            // DisplayButton
            // 
            this.DisplayButton.Location = new System.Drawing.Point(285, 318);
            this.DisplayButton.Name = "DisplayButton";
            this.DisplayButton.Size = new System.Drawing.Size(102, 34);
            this.DisplayButton.TabIndex = 2;
            this.DisplayButton.Text = "D&isplay";
            this.DisplayButton.UseVisualStyleBackColor = true;
            this.DisplayButton.Click += new System.EventHandler(this.DisplayButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(393, 318);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(97, 34);
            this.ClearButton.TabIndex = 3;
            this.ClearButton.Text = "C&lear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ProceedButton
            // 
            this.ProceedButton.Location = new System.Drawing.Point(496, 318);
            this.ProceedButton.Name = "ProceedButton";
            this.ProceedButton.Size = new System.Drawing.Size(100, 34);
            this.ProceedButton.TabIndex = 4;
            this.ProceedButton.Text = "P&roceed";
            this.ProceedButton.UseVisualStyleBackColor = true;
            this.ProceedButton.Click += new System.EventHandler(this.ProceedButton_Click);
            // 
            // InvestementAmountTB
            // 
            this.InvestementAmountTB.Location = new System.Drawing.Point(195, 27);
            this.InvestementAmountTB.Name = "InvestementAmountTB";
            this.InvestementAmountTB.Size = new System.Drawing.Size(150, 31);
            this.InvestementAmountTB.TabIndex = 4;
            // 
            // InvestementLabel
            // 
            this.InvestementLabel.AutoSize = true;
            this.InvestementLabel.Location = new System.Drawing.Point(6, 27);
            this.InvestementLabel.Name = "InvestementLabel";
            this.InvestementLabel.Size = new System.Drawing.Size(183, 25);
            this.InvestementLabel.TabIndex = 3;
            this.InvestementLabel.Text = "Investement Amount:";
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = global::Assignment3_mad4road.Properties.Resources.M4M_Logo;
            this.LogoPictureBox.Location = new System.Drawing.Point(284, 86);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(520, 116);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox.TabIndex = 20;
            this.LogoPictureBox.TabStop = false;
            // 
            // LogoPictureBox1
            // 
            this.LogoPictureBox1.Image = global::Assignment3_mad4road.Properties.Resources.M4M_Logo;
            this.LogoPictureBox1.Location = new System.Drawing.Point(280, 737);
            this.LogoPictureBox1.Name = "LogoPictureBox1";
            this.LogoPictureBox1.Size = new System.Drawing.Size(524, 142);
            this.LogoPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoPictureBox1.TabIndex = 21;
            this.LogoPictureBox1.TabStop = false;
            // 
            // ClientDetailsGroupBox
            // 
            this.ClientDetailsGroupBox.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientDetailsGroupBox.Controls.Add(this.ExitButton);
            this.ClientDetailsGroupBox.Controls.Add(this.TransactionDetailsPanel);
            this.ClientDetailsGroupBox.Controls.Add(this.SubmitPanel);
            this.ClientDetailsGroupBox.Controls.Add(this.EmailTB);
            this.ClientDetailsGroupBox.Controls.Add(this.PhoneNumberTB);
            this.ClientDetailsGroupBox.Controls.Add(this.PostalCodeTB);
            this.ClientDetailsGroupBox.Controls.Add(this.SubmitButton);
            this.ClientDetailsGroupBox.Controls.Add(this.TransactionNumberLabelOP);
            this.ClientDetailsGroupBox.Controls.Add(this.ClientNameTB);
            this.ClientDetailsGroupBox.Location = new System.Drawing.Point(659, 21);
            this.ClientDetailsGroupBox.Name = "ClientDetailsGroupBox";
            this.ClientDetailsGroupBox.Size = new System.Drawing.Size(422, 368);
            this.ClientDetailsGroupBox.TabIndex = 11;
            this.ClientDetailsGroupBox.TabStop = false;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(258, 318);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(112, 34);
            this.ExitButton.TabIndex = 24;
            this.ExitButton.Text = "E&xit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // TransactionDetailsPanel
            // 
            this.TransactionDetailsPanel.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.TransactionDetailsPanel.BackColor = System.Drawing.Color.LightBlue;
            this.TransactionDetailsPanel.Controls.Add(this.TransactionDetailsLabel);
            this.TransactionDetailsPanel.Location = new System.Drawing.Point(42, 30);
            this.TransactionDetailsPanel.Name = "TransactionDetailsPanel";
            this.TransactionDetailsPanel.Size = new System.Drawing.Size(300, 38);
            this.TransactionDetailsPanel.TabIndex = 23;
            // 
            // TransactionDetailsLabel
            // 
            this.TransactionDetailsLabel.AutoSize = true;
            this.TransactionDetailsLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TransactionDetailsLabel.Location = new System.Drawing.Point(62, 3);
            this.TransactionDetailsLabel.Name = "TransactionDetailsLabel";
            this.TransactionDetailsLabel.Size = new System.Drawing.Size(179, 25);
            this.TransactionDetailsLabel.TabIndex = 0;
            this.TransactionDetailsLabel.Text = "Please enter Details";
            // 
            // SubmitPanel
            // 
            this.SubmitPanel.BackColor = System.Drawing.Color.LightBlue;
            this.SubmitPanel.Controls.Add(this.TransactionNumberLabel);
            this.SubmitPanel.Controls.Add(this.ClientNameLabel);
            this.SubmitPanel.Controls.Add(this.EmailLabel);
            this.SubmitPanel.Controls.Add(this.PostalCodeLabel);
            this.SubmitPanel.Controls.Add(this.PhoneNumberLabel);
            this.SubmitPanel.Location = new System.Drawing.Point(15, 73);
            this.SubmitPanel.Name = "SubmitPanel";
            this.SubmitPanel.Size = new System.Drawing.Size(192, 217);
            this.SubmitPanel.TabIndex = 22;
            // 
            // TransactionNumberLabel
            // 
            this.TransactionNumberLabel.AutoSize = true;
            this.TransactionNumberLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TransactionNumberLabel.Location = new System.Drawing.Point(3, 25);
            this.TransactionNumberLabel.Name = "TransactionNumberLabel";
            this.TransactionNumberLabel.Size = new System.Drawing.Size(170, 25);
            this.TransactionNumberLabel.TabIndex = 11;
            this.TransactionNumberLabel.Text = "Transaction Number";
            // 
            // ClientNameLabel
            // 
            this.ClientNameLabel.AutoSize = true;
            this.ClientNameLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ClientNameLabel.Location = new System.Drawing.Point(36, 58);
            this.ClientNameLabel.Name = "ClientNameLabel";
            this.ClientNameLabel.Size = new System.Drawing.Size(108, 25);
            this.ClientNameLabel.TabIndex = 10;
            this.ClientNameLabel.Text = "Client Name";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EmailLabel.Location = new System.Drawing.Point(56, 173);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(54, 25);
            this.EmailLabel.TabIndex = 7;
            this.EmailLabel.Text = "Email";
            // 
            // PostalCodeLabel
            // 
            this.PostalCodeLabel.AutoSize = true;
            this.PostalCodeLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PostalCodeLabel.Location = new System.Drawing.Point(38, 96);
            this.PostalCodeLabel.Name = "PostalCodeLabel";
            this.PostalCodeLabel.Size = new System.Drawing.Size(106, 25);
            this.PostalCodeLabel.TabIndex = 9;
            this.PostalCodeLabel.Text = "Postal Code";
            // 
            // PhoneNumberLabel
            // 
            this.PhoneNumberLabel.AutoSize = true;
            this.PhoneNumberLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PhoneNumberLabel.Location = new System.Drawing.Point(27, 136);
            this.PhoneNumberLabel.Name = "PhoneNumberLabel";
            this.PhoneNumberLabel.Size = new System.Drawing.Size(132, 25);
            this.PhoneNumberLabel.TabIndex = 8;
            this.PhoneNumberLabel.Text = "Phone Number";
            // 
            // EmailTB
            // 
            this.EmailTB.Location = new System.Drawing.Point(226, 241);
            this.EmailTB.Name = "EmailTB";
            this.EmailTB.Size = new System.Drawing.Size(170, 31);
            this.EmailTB.TabIndex = 20;
            // 
            // PhoneNumberTB
            // 
            this.PhoneNumberTB.Location = new System.Drawing.Point(226, 201);
            this.PhoneNumberTB.Name = "PhoneNumberTB";
            this.PhoneNumberTB.Size = new System.Drawing.Size(170, 31);
            this.PhoneNumberTB.TabIndex = 21;
            // 
            // PostalCodeTB
            // 
            this.PostalCodeTB.Location = new System.Drawing.Point(227, 164);
            this.PostalCodeTB.Name = "PostalCodeTB";
            this.PostalCodeTB.Size = new System.Drawing.Size(169, 31);
            this.PostalCodeTB.TabIndex = 22;
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(131, 318);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(112, 34);
            this.SubmitButton.TabIndex = 12;
            this.SubmitButton.Text = "S&ubmit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // TransactionNumberLabelOP
            // 
            this.TransactionNumberLabelOP.BackColor = System.Drawing.SystemColors.Window;
            this.TransactionNumberLabelOP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TransactionNumberLabelOP.Location = new System.Drawing.Point(227, 94);
            this.TransactionNumberLabelOP.Name = "TransactionNumberLabelOP";
            this.TransactionNumberLabelOP.Size = new System.Drawing.Size(169, 27);
            this.TransactionNumberLabelOP.TabIndex = 12;
            // 
            // ClientNameTB
            // 
            this.ClientNameTB.BackColor = System.Drawing.SystemColors.Window;
            this.ClientNameTB.Location = new System.Drawing.Point(226, 126);
            this.ClientNameTB.Name = "ClientNameTB";
            this.ClientNameTB.Size = new System.Drawing.Size(170, 31);
            this.ClientNameTB.TabIndex = 17;
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.BackColor = System.Drawing.Color.LemonChiffon;
            this.SearchGroupBox.Controls.Add(this.panel2);
            this.SearchGroupBox.Controls.Add(this.panel1);
            this.SearchGroupBox.Controls.Add(this.SearchResultsListBox);
            this.SearchGroupBox.Location = new System.Drawing.Point(508, 403);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(556, 328);
            this.SearchGroupBox.TabIndex = 19;
            this.SearchGroupBox.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.Controls.Add(this.SearchResultsLabel);
            this.panel2.Location = new System.Drawing.Point(131, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 38);
            this.panel2.TabIndex = 28;
            // 
            // SearchResultsLabel
            // 
            this.SearchResultsLabel.AutoSize = true;
            this.SearchResultsLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SearchResultsLabel.Location = new System.Drawing.Point(85, 4);
            this.SearchResultsLabel.Name = "SearchResultsLabel";
            this.SearchResultsLabel.Size = new System.Drawing.Size(135, 25);
            this.SearchResultsLabel.TabIndex = 25;
            this.SearchResultsLabel.Text = "Search Results";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.SearchClearButton);
            this.panel1.Controls.Add(this.SearchButton);
            this.panel1.Controls.Add(this.SearchTextBox);
            this.panel1.Controls.Add(this.EmailRadioButton);
            this.panel1.Controls.Add(this.TransactionRadioButton);
            this.panel1.Location = new System.Drawing.Point(19, 67);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(190, 231);
            this.panel1.TabIndex = 27;
            // 
            // SearchClearButton
            // 
            this.SearchClearButton.Location = new System.Drawing.Point(47, 183);
            this.SearchClearButton.Name = "SearchClearButton";
            this.SearchClearButton.Size = new System.Drawing.Size(112, 34);
            this.SearchClearButton.TabIndex = 24;
            this.SearchClearButton.Text = "C&lear";
            this.SearchClearButton.UseVisualStyleBackColor = true;
            this.SearchClearButton.Click += new System.EventHandler(this.SearchClearButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(47, 143);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(112, 34);
            this.SearchButton.TabIndex = 23;
            this.SearchButton.Text = "S&earch";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchTextBox
            // 
            this.SearchTextBox.Location = new System.Drawing.Point(21, 89);
            this.SearchTextBox.Name = "SearchTextBox";
            this.SearchTextBox.Size = new System.Drawing.Size(158, 31);
            this.SearchTextBox.TabIndex = 22;
            // 
            // EmailRadioButton
            // 
            this.EmailRadioButton.AutoSize = true;
            this.EmailRadioButton.Location = new System.Drawing.Point(21, 12);
            this.EmailRadioButton.Name = "EmailRadioButton";
            this.EmailRadioButton.Size = new System.Drawing.Size(79, 29);
            this.EmailRadioButton.TabIndex = 20;
            this.EmailRadioButton.TabStop = true;
            this.EmailRadioButton.Text = "Email";
            this.EmailRadioButton.UseVisualStyleBackColor = true;
            // 
            // TransactionRadioButton
            // 
            this.TransactionRadioButton.AutoSize = true;
            this.TransactionRadioButton.Location = new System.Drawing.Point(21, 47);
            this.TransactionRadioButton.Name = "TransactionRadioButton";
            this.TransactionRadioButton.Size = new System.Drawing.Size(158, 29);
            this.TransactionRadioButton.TabIndex = 21;
            this.TransactionRadioButton.TabStop = true;
            this.TransactionRadioButton.Text = "Transaction No.\r\n";
            this.TransactionRadioButton.UseVisualStyleBackColor = true;
            // 
            // SearchResultsListBox
            // 
            this.SearchResultsListBox.FormattingEnabled = true;
            this.SearchResultsListBox.ItemHeight = 25;
            this.SearchResultsListBox.Location = new System.Drawing.Point(225, 69);
            this.SearchResultsListBox.Name = "SearchResultsListBox";
            this.SearchResultsListBox.Size = new System.Drawing.Size(311, 229);
            this.SearchResultsListBox.TabIndex = 26;
            // 
            // SummaryListBox
            // 
            this.SummaryListBox.BackColor = System.Drawing.Color.LightBlue;
            this.SummaryListBox.FormattingEnabled = true;
            this.SummaryListBox.ItemHeight = 25;
            this.SummaryListBox.Location = new System.Drawing.Point(24, 77);
            this.SummaryListBox.Name = "SummaryListBox";
            this.SummaryListBox.Size = new System.Drawing.Size(333, 204);
            this.SummaryListBox.TabIndex = 17;
            // 
            // SummaryGroupBox
            // 
            this.SummaryGroupBox.BackColor = System.Drawing.Color.LemonChiffon;
            this.SummaryGroupBox.Controls.Add(this.SummaryPanel);
            this.SummaryGroupBox.Controls.Add(this.label10);
            this.SummaryGroupBox.Controls.Add(this.label9);
            this.SummaryGroupBox.Controls.Add(this.label8);
            this.SummaryGroupBox.Controls.Add(this.TotalAmountLabel);
            this.SummaryGroupBox.Controls.Add(this.TotalInterestOccuring);
            this.SummaryGroupBox.Controls.Add(this.AverageDuration);
            this.SummaryGroupBox.Controls.Add(this.AverageAmount);
            this.SummaryGroupBox.Controls.Add(this.TotalAmountBorrowedLabel);
            this.SummaryGroupBox.Controls.Add(this.SummaryButton);
            this.SummaryGroupBox.Controls.Add(this.SummaryListBox);
            this.SummaryGroupBox.Location = new System.Drawing.Point(66, 403);
            this.SummaryGroupBox.Name = "SummaryGroupBox";
            this.SummaryGroupBox.Size = new System.Drawing.Size(414, 328);
            this.SummaryGroupBox.TabIndex = 18;
            this.SummaryGroupBox.TabStop = false;
            // 
            // SummaryPanel
            // 
            this.SummaryPanel.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.SummaryPanel.BackColor = System.Drawing.Color.LightBlue;
            this.SummaryPanel.Controls.Add(this.SummaryLabel);
            this.SummaryPanel.Location = new System.Drawing.Point(38, 33);
            this.SummaryPanel.Name = "SummaryPanel";
            this.SummaryPanel.Size = new System.Drawing.Size(300, 38);
            this.SummaryPanel.TabIndex = 27;
            // 
            // SummaryLabel
            // 
            this.SummaryLabel.AutoSize = true;
            this.SummaryLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SummaryLabel.Location = new System.Drawing.Point(62, 3);
            this.SummaryLabel.Name = "SummaryLabel";
            this.SummaryLabel.Size = new System.Drawing.Size(179, 25);
            this.SummaryLabel.TabIndex = 0;
            this.SummaryLabel.Text = "Please enter Details";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.LightBlue;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(38, 250);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 25);
            this.label10.TabIndex = 26;
            this.label10.Text = "Avg Duration:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.LightBlue;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(38, 165);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 25);
            this.label9.TabIndex = 25;
            this.label9.Text = "Total Interest:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.LightBlue;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(38, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 25);
            this.label8.TabIndex = 24;
            this.label8.Text = "Avg Amount:";
            // 
            // TotalAmountLabel
            // 
            this.TotalAmountLabel.AutoSize = true;
            this.TotalAmountLabel.BackColor = System.Drawing.Color.LightBlue;
            this.TotalAmountLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TotalAmountLabel.Location = new System.Drawing.Point(32, 118);
            this.TotalAmountLabel.Name = "TotalAmountLabel";
            this.TotalAmountLabel.Size = new System.Drawing.Size(123, 25);
            this.TotalAmountLabel.TabIndex = 23;
            this.TotalAmountLabel.Text = "Total Amount:";
            // 
            // TotalInterestOccuring
            // 
            this.TotalInterestOccuring.BackColor = System.Drawing.SystemColors.Window;
            this.TotalInterestOccuring.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalInterestOccuring.Location = new System.Drawing.Point(200, 165);
            this.TotalInterestOccuring.Name = "TotalInterestOccuring";
            this.TotalInterestOccuring.Size = new System.Drawing.Size(147, 25);
            this.TotalInterestOccuring.TabIndex = 22;
            // 
            // AverageDuration
            // 
            this.AverageDuration.BackColor = System.Drawing.SystemColors.Window;
            this.AverageDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AverageDuration.Location = new System.Drawing.Point(200, 250);
            this.AverageDuration.Name = "AverageDuration";
            this.AverageDuration.Size = new System.Drawing.Size(147, 25);
            this.AverageDuration.TabIndex = 21;
            // 
            // AverageAmount
            // 
            this.AverageAmount.BackColor = System.Drawing.SystemColors.Window;
            this.AverageAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AverageAmount.Location = new System.Drawing.Point(200, 210);
            this.AverageAmount.Name = "AverageAmount";
            this.AverageAmount.Size = new System.Drawing.Size(147, 25);
            this.AverageAmount.TabIndex = 20;
            // 
            // TotalAmountBorrowedLabel
            // 
            this.TotalAmountBorrowedLabel.BackColor = System.Drawing.SystemColors.Window;
            this.TotalAmountBorrowedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalAmountBorrowedLabel.Location = new System.Drawing.Point(200, 117);
            this.TotalAmountBorrowedLabel.Name = "TotalAmountBorrowedLabel";
            this.TotalAmountBorrowedLabel.Size = new System.Drawing.Size(147, 26);
            this.TotalAmountBorrowedLabel.TabIndex = 19;
            // 
            // SummaryButton
            // 
            this.SummaryButton.Location = new System.Drawing.Point(135, 287);
            this.SummaryButton.Name = "SummaryButton";
            this.SummaryButton.Size = new System.Drawing.Size(112, 34);
            this.SummaryButton.TabIndex = 18;
            this.SummaryButton.Text = "S&ummary";
            this.SummaryButton.UseVisualStyleBackColor = true;
            this.SummaryButton.Click += new System.EventHandler(this.SummaryButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(886, 445);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 11;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1093, 900);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LogoPictureBox1);
            this.Controls.Add(this.ClientDetailsGroupBox);
            this.Controls.Add(this.LogoPictureBox);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.InvestementGroupBox);
            this.Controls.Add(this.LoginGroupBox);
            this.Controls.Add(this.SummaryGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Mad4Money Bank Corp";
            this.LoginGroupBox.ResumeLayout(false);
            this.LoginGroupBox.PerformLayout();
            this.InvestementGroupBox.ResumeLayout(false);
            this.InvestementGroupBox.PerformLayout();
            this.CalculationPanel.ResumeLayout(false);
            this.CalculationPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox1)).EndInit();
            this.ClientDetailsGroupBox.ResumeLayout(false);
            this.ClientDetailsGroupBox.PerformLayout();
            this.TransactionDetailsPanel.ResumeLayout(false);
            this.TransactionDetailsPanel.PerformLayout();
            this.SubmitPanel.ResumeLayout(false);
            this.SubmitPanel.PerformLayout();
            this.SearchGroupBox.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.SummaryGroupBox.ResumeLayout(false);
            this.SummaryGroupBox.PerformLayout();
            this.SummaryPanel.ResumeLayout(false);
            this.SummaryPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private GroupBox LoginGroupBox;
        private Button LoginButton;
        private TextBox PasswordTB;
        private GroupBox InvestementGroupBox;
        private Button DisplayButton;
        private Button ClearButton;
        private Button ProceedButton;
        private Label InterestRateLB;
        private Label MonthlyInterestLB;
        private Label TotalInterestLB;
        private Label TotalAmountLB;
        private Label TermLB;
        private TextBox InvestementAmountTB;
        private Label InvestementLabel;
        private GroupBox ClientDetailsGroupBox;
        private Button SubmitButton;
        private Label TransactionNumberLabelOP;
        private Label TransactionNumberLabel;
        private Label ClientNameLabel;
        private Label PostalCodeLabel;
        private Label PhoneNumberLabel;
        private Label EmailLabel;
        private ListBox SummaryListBox;
        private GroupBox SummaryGroupBox;
        private Button SummaryButton;
        private GroupBox SearchGroupBox;
        private ListBox SearchResultsListBox;
        private Label SearchResultsLabel;
        private Button SearchClearButton;
        private Button SearchButton;
        private TextBox SearchTextBox;
        private RadioButton TransactionRadioButton;
        private RadioButton EmailRadioButton;
        private TextBox EmailTB;
        private TextBox PhoneNumberTB;
        private TextBox PostalCodeTB;
        private TextBox ClientNameTB;
        private ListBox CalculationListBox;
        private Label TotalInterestOccuring;
        private Label AverageDuration;
        private Label AverageAmount;
        private Label TotalAmountBorrowedLabel;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label TotalAmountLabel;
        private PictureBox LogoPictureBox;
        private PictureBox LogoPictureBox1;
        private Label label1;
        private Panel CalculationPanel;
        private Panel TransactionDetailsPanel;
        private Label TransactionDetailsLabel;
        private Panel SubmitPanel;
        private Panel panel1;
        private Panel SummaryPanel;
        private Label SummaryLabel;
        private Panel panel2;
        private Label label2;
        private Label RoadSideAssitanceLabel;
        private Button ExitButton;
    }
}